#!/usr/bin/env bash
# Take a physical base backup while captured history is pending, archive WAL, and
# restore it twice: to a named restore point and to the end of the archive. Each
# restored cluster must agree with the state the primary had at that point, and
# capture, apply and prune must keep working on it. Uses a private copy of the
# production PostgreSQL install; the original is untouched.
set -euo pipefail
SYNTRA_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SYNTRA_ROOT"
bash scripts/setup-production.sh
export PGRX_HOME="$SYNTRA_ROOT/.pgrx"
export PATH="$SYNTRA_ROOT/.tools/bin:$PATH"
WORK="$SYNTRA_ROOT/target/physical-restore-check/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$WORK/archive"
cp -R .tools/postgresql-production/18.6/install "$WORK/pg"
BIN="$WORK/pg/bin"
(cd crates/syntra-pg && CARGO_TARGET_DIR="$SYNTRA_ROOT/target/upgrade-current" cargo pgrx install \
    --release --cargo=--locked --pg-config "$WORK/pg/bin/pg_config")

SOCKET="$(mktemp -d /tmp/syntra-restore.XXXXXX)"
"$BIN/initdb" -D "$WORK/primary" --username=restorer --auth=trust --no-locale --encoding=UTF8 >/dev/null
configure() {
    printf "\nlisten_addresses = ''\nunix_socket_directories = '%s'\nport = %s\n" "$SOCKET" "$2" >>"$1/postgresql.conf"
}
configure "$WORK/primary" 28932
printf "wal_level = replica\narchive_mode = on\narchive_command = 'cp %%p %s/archive/%%f'\n" "$WORK" \
    >>"$WORK/primary/postgresql.conf"
RUNNING=()
start() { "$BIN/pg_ctl" -D "$1" -l "$1.log" -w -t 60 start >/dev/null; RUNNING+=("$1"); }
stop() { "$BIN/pg_ctl" -D "$1" -w -t 30 stop -m fast >/dev/null; }
cleanup() { for d in "${RUNNING[@]}"; do stop "$d" 2>/dev/null || true; done; }
trap cleanup EXIT
q() { "$BIN/psql" -h "$SOCKET" -p "$1" -U restorer -d restored -v ON_ERROR_STOP=1 -AtqX -c "$2"; }
expect() {
    if [[ "$2" != "$3" ]]; then
        echo "physical restore check failed: $1: got '$2', expected '$3'" >&2
        exit 1
    fi
}
READ="SELECT s.route||':'||(ROW(s.rows,s.non_nulls,s.sum,s.min,s.max) IS NOT DISTINCT FROM ROW(n.rows,n.non_nulls,n.sum,n.min,n.max))
    FROM syntra_checkpoint_int4_summary('feed','v',true) AS s,
    (SELECT count(*) AS rows,count(v) AS non_nulls,sum(v),min(v),max(v) FROM feed) AS n"
HEAP="SELECT concat_ws(',',count(*),count(v),sum(v),min(v),max(v)) FROM feed"
LAG="SELECT concat_ws(',',emitted,applied,pending_events,generation) FROM syntra_capture_lag('feed')"

start "$WORK/primary"
"$BIN/psql" -h "$SOCKET" -p 28932 -U restorer -d postgres -v ON_ERROR_STOP=1 -AtqX -c "CREATE DATABASE restored" >/dev/null
q 28932 "CREATE EXTENSION syntradb"
q 28932 "CREATE TABLE feed(id int4 PRIMARY KEY,v int4); INSERT INTO feed SELECT g,g FROM generate_series(1,1000) AS g"
q 28932 "SELECT syntra_seed_capture('feed','id','v',4096)" >/dev/null
q 28932 "SELECT syntra_apply_capture('feed')" >/dev/null
q 28932 "UPDATE feed SET v=v+1 WHERE id<=100"
q 28932 "SELECT applied FROM syntra_apply_prune_capture('feed')" >/dev/null
# History captured before the backup and never applied.
q 28932 "UPDATE feed SET v=-v WHERE id BETWEEN 101 AND 150"
# Captured writes, with apply and prune every 100, keep committing while the base
# backup is taken. The feed position must move during the backup.
for i in $(seq 1 3000); do
    echo "UPDATE feed SET v=coalesce(v,0)+1 WHERE id=$((i % 900 + 1));"
    if ((i % 100 == 0)); then echo "SELECT applied FROM syntra_apply_prune_capture('feed');"; fi
done >"$WORK/writes.sql"
STARTED_AT="$(q 28932 "SELECT emitted FROM syntra_capture_lag('feed')")"
"$BIN/psql" -h "$SOCKET" -p 28932 -U restorer -d restored -v ON_ERROR_STOP=1 -AtqX -f "$WORK/writes.sql" >/dev/null &
WRITER=$!
until (($(q 28932 "SELECT emitted FROM syntra_capture_lag('feed')") > STARTED_AT + 50)); do sleep 0.05; done
BEFORE_BACKUP="$(q 28932 "SELECT emitted FROM syntra_capture_lag('feed')")"
"$BIN/pg_basebackup" -h "$SOCKET" -p 28932 -U restorer -D "$WORK/backup" -X stream -c fast
AFTER_BACKUP="$(q 28932 "SELECT emitted FROM syntra_capture_lag('feed')")"
wait "$WRITER"
if ((AFTER_BACKUP <= BEFORE_BACKUP)); then
    echo "physical restore check failed: no captured write committed during the base backup" >&2
    exit 1
fi

# Point A: written after the backup, partly applied, with history still pending.
q 28932 "DELETE FROM feed WHERE id BETWEEN 990 AND 1000"
q 28932 "INSERT INTO feed SELECT g,NULL FROM generate_series(2001,2020) AS g"
q 28932 "SELECT applied FROM syntra_apply_prune_capture('feed')" >/dev/null
q 28932 "UPDATE feed SET v=7 WHERE id BETWEEN 200 AND 230"
expect "primary read at A" "$(q 28932 "$READ")" "replay:true"
HEAP_A="$(q 28932 "$HEAP")"
LAG_A="$(q 28932 "$LAG")"
q 28932 "SELECT pg_create_restore_point('syntra_a')" >/dev/null
# Point B: everything after A, applied and pruned, then more pending history.
q 28932 "UPDATE feed SET v=coalesce(v,0)+1000 WHERE id%3=0"
q 28932 "SELECT applied FROM syntra_apply_prune_capture('feed')" >/dev/null
q 28932 "UPDATE feed SET id=id+5000 WHERE id BETWEEN 300 AND 310"
expect "primary read at B" "$(q 28932 "$READ")" "replay:true"
HEAP_B="$(q 28932 "$HEAP")"
LAG_B="$(q 28932 "$LAG")"
if [[ "$HEAP_A" == "$HEAP_B" || "$LAG_A" == "$LAG_B" ]]; then
    echo "physical restore check failed: points A and B are indistinguishable" >&2
    exit 1
fi
q 28932 "SELECT pg_switch_wal()" >/dev/null
q 28932 "CHECKPOINT"
stop "$WORK/primary"

# Restore the same base backup into $1 on port $2, replaying archived WAL up to
# the recovery target given in $3 (empty means the end of the archive).
restore() {
    cp -R "$WORK/backup" "$1"
    chmod 700 "$1"
    configure "$1" "$2"
    printf "archive_mode = off\nrestore_command = 'cp %s/archive/%%f %%p'\nrecovery_target_action = 'promote'\n%s\n" \
        "$WORK" "$3" >>"$1/postgresql.conf"
    touch "$1/recovery.signal"
    start "$1"
    local tries=0
    until [[ "$(q "$2" "SELECT pg_is_in_recovery()")" == "f" ]]; do
        tries=$((tries + 1))
        if ((tries > 300)); then
            echo "physical restore check failed: $1 did not finish recovery in 60 s" >&2
            exit 1
        fi
        sleep 0.2
    done
}
check_restored() {
    expect "$1 heap" "$(q "$2" "$HEAP")" "$3"
    expect "$1 lag" "$(q "$2" "$LAG")" "$4"
    expect "$1 read" "$(q "$2" "$READ")" "replay:true"
    # The restored feed must keep capturing, applying and pruning.
    q "$2" "UPDATE feed SET v=1 WHERE id=1"
    q "$2" "SELECT applied FROM syntra_apply_prune_capture('feed')" >/dev/null
    expect "$1 drained lag" "$(q "$2" "SELECT pending_events FROM syntra_capture_lag('feed')")" "0"
    expect "$1 drained read" "$(q "$2" "$READ")" "checkpoint:true"
    expect "$1 headroom" "$(q "$2" "SELECT retained_events FROM syntra_capture_headroom('feed')")" "0"
}
restore "$WORK/at-a" 28933 "recovery_target_name = 'syntra_a'"
check_restored "restore point A" 28933 "$HEAP_A" "$LAG_A"
stop "$WORK/at-a"
restore "$WORK/at-end" 28934 ""
check_restored "end of archive" 28934 "$HEAP_B" "$LAG_B"
echo "physical restore check passed: base backup taken during captured writes ($((AFTER_BACKUP - BEFORE_BACKUP)) events), with pending history, restored to a named point and to the end of archived WAL; work dir $WORK"
