//! Saturated capture/apply/prune correctness stress, including a retained snapshot.
use crate::Cluster;
use postgres::{Client, Statement};
use serde_json::{json, Value};
use std::{
    collections::BTreeMap,
    sync::atomic::{AtomicBool, AtomicU64, Ordering},
    thread,
    time::{Duration, Instant},
};
use syntra_bench::{
    arrival_offset, checkpoint_due_slot, correctness_values, AggregateValues, LatencyHistogram,
    Options, Result,
};
use syntra_storage::chunks::{chunk_binding, digest, partition, Manifest, PARTITIONS};
use syntra_storage::replay::{Batch, Change, Limits, ReplayState, Row};

const READ: &str = "SELECT s.rows,s.non_nulls,s.sum,s.min,s.max,s.route,s.reason, ROW(s.rows,s.non_nulls,s.sum,s.min,s.max) IS NOT DISTINCT FROM ROW(n.rows,n.non_nulls,n.sum,n.min,n.max), pg_current_xact_id_if_assigned() IS NULL FROM syntra_checkpoint_int4_summary('checkpoint_stress_source','v',$1) AS s,(SELECT count(*) AS rows,count(v) AS non_nulls,sum(v),min(v),max(v) FROM checkpoint_stress_source) AS n LIMIT 1";
const APPLY: &str = "SELECT syntra_apply_capture('checkpoint_stress_source')";
const COMBINED: &str =
    "SELECT applied,pruned FROM syntra_apply_prune_capture('checkpoint_stress_source')";
const PRUNE: &str = "SELECT syntra_prune_capture('checkpoint_stress_source')";
const TRANSFER: &str =
    "UPDATE checkpoint_stress_source SET v=v+CASE WHEN id=$1 THEN -1 ELSE 1 END WHERE id IN($1,$2)";
const PROGRESS: &str = "SELECT h.epoch,h.emitted,h.pruned,h.live_rows,c.applied,c.manifest FROM (SELECT hh.source_relation,hh.epoch,hh.base_rows,hh.pruned,coalesce(m.ordinal,hh.emitted) AS emitted,coalesce(m.live_rows,hh.live_rows) AS live_rows FROM syntra.capture_heads AS hh LEFT JOIN LATERAL (SELECT ordinal,live_rows FROM syntra.capture_marks WHERE epoch=hh.epoch AND ordinal>hh.emitted ORDER BY ordinal DESC LIMIT 1) AS m ON true) AS h JOIN syntra.capture_checkpoints AS c USING(source_relation,epoch) WHERE h.source_relation='checkpoint_stress_source'::regclass LIMIT 1";
// Soak vacuum runs on its own clock, independent of the offered worker rate.
const VACUUM_INTERVAL: Duration = Duration::from_secs(5);
const VACUUM: &str = "VACUUM (ANALYZE) syntra.capture_events, syntra.capture_marks, syntra.capture_chunks, syntra.capture_checkpoints, syntra.capture_heads, checkpoint_stress_source";
const LIMITS: Limits = Limits {
    rows: 1_000_000,
    changes: 4096,
    buffer_bytes: 32 * 1024 * 1024,
};

struct Stats {
    name: &'static str,
    attempts: u64,
    commits: u64,
    rollbacks: u64,
    checks: u64,
    keyed_checks: u64,
    pruned: u64,
    max_pending: i64,
    max_retained: i64,
    vacuums: u64,
    rejections: BTreeMap<&'static str, u64>,
    routes: BTreeMap<String, u64>,
    latency: LatencyHistogram,
    rejected_latency: LatencyHistogram,
    start_skew_ms: f64,
    planned: u64,
    scheduled_latency: LatencyHistogram,
    scheduled_rejected_latency: LatencyHistogram,
}
impl Stats {
    fn new(name: &'static str, start: Instant) -> Result<Self> {
        Ok(Self {
            name,
            attempts: 0,
            commits: 0,
            rollbacks: 0,
            checks: 0,
            keyed_checks: 0,
            pruned: 0,
            max_pending: 0,
            max_retained: 0,
            vacuums: 0,
            rejections: BTreeMap::new(),
            routes: BTreeMap::new(),
            latency: LatencyHistogram::new()?,
            rejected_latency: LatencyHistogram::new()?,
            planned: 0,
            scheduled_latency: LatencyHistogram::new()?,
            scheduled_rejected_latency: LatencyHistogram::new()?,
            start_skew_ms: start.elapsed().as_secs_f64() * 1000.0,
        })
    }
    fn report(&self) -> Value {
        json!({"name":self.name,"attempts":self.attempts,"commits":self.commits,"intentional_rollbacks":self.rollbacks,"aggregate_checks":self.checks,"keyed_checks":self.keyed_checks,"events_pruned":self.pruned,"sampled_max_pending_events":self.max_pending,"sampled_max_retained_events":self.max_retained,"vacuum_operations":self.vacuums,"expected_rejections":self.rejections,"read_routes_and_reasons":self.routes,"successful_cycle_latency":self.latency.report(),"rejected_cycle_latency":self.rejected_latency.report(),"start_skew_ms":self.start_skew_ms,"planned_arrivals":self.planned,"missed_arrivals":self.planned.saturating_sub(self.attempts),"successful_scheduled_latency":self.scheduled_latency.report(),"rejected_scheduled_latency":self.scheduled_rejected_latency.report()})
    }
}
fn require(ok: bool, message: &'static str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(message.into())
    }
}
fn read(
    client: &mut Client,
    statement: &Statement,
    stats: &mut Stats,
    own: bool,
    total: i64,
    replay: bool,
) -> Result<AggregateValues> {
    let row = client.query_one(statement, &[&replay])?;
    let values = correctness_values(&row)?;
    let route: &str = row.try_get(5)?;
    let reason: &str = row.try_get(6)?;
    require(
        row.try_get::<_, bool>(7)? && row.try_get::<_, bool>(8)? != own && values.2 == Some(total),
        "checkpoint stress aggregate or snapshot invariant failed",
    )?;
    require(
        matches!(route, "checkpoint" | "replay" | "heap")
            && (replay || route != "replay")
            && (route != "replay" || reason == "bounded_tail")
            && (!own || (route == "heap" && reason == "transaction_has_xid")),
        "checkpoint stress route invariant failed",
    )?;
    *stats.routes.entry(format!("{route}/{reason}")).or_default() += 1;
    stats.checks += 1;
    Ok(values)
}
fn keyed_check(client: &mut Client, stats: &mut Stats, rows: i32) -> Result<()> {
    client.batch_execute("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY")?;
    let head = client.query_one(PROGRESS, &[])?;
    let epoch: i64 = head.try_get(0)?;
    let emitted: i64 = head.try_get(1)?;
    let pruned: i64 = head.try_get(2)?;
    let live: i64 = head.try_get(3)?;
    let applied: i64 = head.try_get(4)?;
    require(
        epoch > 0
            && 0 <= pruned
            && pruned <= applied
            && applied <= emitted
            && emitted - pruned <= 4096
            && live == i64::from(rows),
        "checkpoint stress head, retention or row-count invariant failed",
    )?;
    stats.max_pending = stats.max_pending.max(emitted - applied);
    stats.max_retained = stats.max_retained.max(emitted - pruned);
    let bytes: Vec<u8> = head.try_get(5)?;
    let manifest = Manifest::decode(&bytes)?;
    require(
        manifest.applied == applied as u64
            && manifest.binding.epoch == epoch as u64
            && manifest.rows()? == rows as u32,
        "checkpoint stress durable cursor disagreed with manifest",
    )?;
    let chunks=client.query("SELECT partition,epoch,revision,row_count,state,segment FROM syntra.capture_chunks WHERE source_relation='checkpoint_stress_source'::regclass ORDER BY partition LIMIT 65",&[])?;
    require(
        chunks.len() == PARTITIONS,
        "checkpoint stress missing chunk",
    )?;
    let mut assembled = Vec::new();
    for (index, chunk) in chunks.iter().enumerate() {
        let reference = &manifest.chunks[index];
        let state_bytes: Vec<u8> = chunk.try_get(4)?;
        let segment: Vec<u8> = chunk.try_get(5)?;
        require(
            chunk.try_get::<_, i16>(0)? == index as i16
                && chunk.try_get::<_, i64>(1)? == epoch
                && chunk.try_get::<_, i64>(2)? == reference.revision as i64
                && chunk.try_get::<_, i64>(3)? == i64::from(reference.rows)
                && digest(&state_bytes, || true)? == reference.state_digest
                && digest(&segment, || true)? == reference.segment_digest,
            "checkpoint stress chunk reference mismatch",
        )?;
        let state = ReplayState::decode_checkpoint(&state_bytes, LIMITS, || true)?;
        require(
            state.binding() == chunk_binding(manifest.binding, index)?
                && state.sequence() == reference.revision
                && state.rows().len() == reference.rows as usize
                && state.rows().iter().all(|r| partition(r.key) == index),
            "checkpoint stress chunk state mismatch",
        )?;
        let column = syntra_storage::Int4Segment::open(&segment, || true)?;
        let mut values = Vec::new();
        for group in column.groups() {
            values.extend(group?.values());
        }
        require(
            values
                .iter()
                .copied()
                .eq(state.rows().iter().map(|r| r.value)),
            "checkpoint stress chunk representations disagree",
        )?;
        assembled.extend_from_slice(state.rows());
    }
    assembled.sort_unstable_by_key(|r| r.key);
    let mut state =
        ReplayState::seed(manifest.binding, applied as u64, &assembled, LIMITS, || {
            true
        })?;
    let events=client.query("SELECT ordinal,key,before_present,before_value,after_present,after_value FROM syntra.capture_events WHERE source_relation='checkpoint_stress_source'::regclass AND epoch=$1 AND ordinal>$2 ORDER BY ordinal LIMIT 4097",&[&epoch,&applied])?;
    require(
        events.len() as i64 == emitted - applied,
        "checkpoint stress lost pending capture events",
    )?;
    let mut changes = Vec::new();
    for (index, event) in events.iter().enumerate() {
        let ordinal: i64 = event.try_get(0)?;
        require(
            ordinal == applied + index as i64 + 1,
            "checkpoint stress pending event ordinal gap",
        )?;
        let before: bool = event.try_get(2)?;
        let old: Option<i32> = event.try_get(3)?;
        let present: bool = event.try_get(4)?;
        let value: Option<i32> = event.try_get(5)?;
        require(
            (before || old.is_none()) && (present || value.is_none()),
            "checkpoint stress invalid event presence flags",
        )?;
        changes.push(Change {
            key: event.try_get(1)?,
            before: before.then_some(old),
            after: present.then_some(value),
        });
    }
    if !changes.is_empty() {
        state.apply_events(
            Batch {
                binding: state.binding(),
                previous: applied as u64,
                next: emitted as u64,
                changes: &changes,
            },
            || true,
        )?;
    }
    let native = client.query(
        "SELECT id,v FROM checkpoint_stress_source ORDER BY id LIMIT 100003",
        &[],
    )?;
    require(
        native.len() == state.rows().len(),
        "checkpoint stress keyed row count mismatch",
    )?;
    for (row, expected) in native.iter().zip(state.rows()) {
        require(
            *expected
                == Row {
                    key: row.try_get(0)?,
                    value: row.try_get(1)?,
                },
            "checkpoint stress keyed row value mismatch",
        )?;
    }
    client.batch_execute("COMMIT")?;
    stats.keyed_checks += 1;
    Ok(())
}
#[derive(Clone, Copy)]
enum Actor {
    Writer(i32),
    Reader(bool),
    Applier,
    Pruner,
    Monitor,
    Vacuum,
}
struct Worker {
    replay: bool,
    client: Client,
    actor: Actor,
    read: Statement,
    transfer: Statement,
    apply: Statement,
    prune: Statement,
    combined: Statement,
    combined_maintenance: bool,
    monitor_vacuum: bool,
    // Soak workers keep their session open after the deadline until the sampler
    // has measured their backend for the final window and sets `stop`.
    hold_until_stop: bool,
    rate: u64,
    name: &'static str,
}
fn rejection(error: &postgres::Error, actor: Actor) -> Option<&'static str> {
    match error.code()?.code() {
        "55P03" => Some("lock_unavailable"),
        "40P01" if matches!(actor,Actor::Writer(_)|Actor::Applier|Actor::Pruner) => Some("deadlock"),
        "54000" if matches!(actor,Actor::Writer(_)) && error.as_db_error()?.message()=="capture log is full or registration changed; apply and prune or reseed before writing" => Some("capture_full"),
        _=>None,
    }
}
fn writer(worker: &mut Worker, stats: &mut Stats, index: i32, rows: i32, total: i64) -> Result<()> {
    worker.client.batch_execute("BEGIN")?;
    let left = index * 2 + 1;
    let right = left + 1;
    require(
        worker.client.execute(&worker.transfer, &[&left, &right])? == 2,
        "checkpoint stress transfer row count mismatch",
    )?;
    let temporary = rows + index + 1;
    let moved = temporary + 2;
    require(
        worker.client.execute(
            "INSERT INTO checkpoint_stress_source(id,v) VALUES($1,NULL)",
            &[&temporary],
        )? == 1,
        "checkpoint stress insert row count mismatch",
    )?;
    require(
        worker.client.execute(
            "UPDATE checkpoint_stress_source SET id=$2,v=7 WHERE id=$1",
            &[&temporary, &moved],
        )? == 1,
        "checkpoint stress key move row count mismatch",
    )?;
    if stats.attempts.is_multiple_of(31) {
        read(
            &mut worker.client,
            &worker.read,
            stats,
            true,
            total + 7,
            worker.replay,
        )?;
    }
    require(
        worker.client.execute(
            "DELETE FROM checkpoint_stress_source WHERE id=$1",
            &[&moved],
        )? == 1,
        "checkpoint stress delete row count mismatch",
    )?;
    if stats.attempts.is_multiple_of(11) {
        worker.client.batch_execute("ROLLBACK")?;
        stats.rollbacks += 1;
    } else {
        worker.client.batch_execute("COMMIT")?;
        stats.commits += 1;
    }
    Ok(())
}
fn cycle(worker: &mut Worker, stats: &mut Stats, rows: i32, total: i64) -> Result<()> {
    match worker.actor {
        Actor::Writer(index) => writer(worker, stats, index, rows, total)?,
        Actor::Reader(repeatable) => {
            if repeatable {
                worker
                    .client
                    .batch_execute("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY")?;
            }
            let first = read(
                &mut worker.client,
                &worker.read,
                stats,
                false,
                total,
                worker.replay,
            )?;
            if repeatable {
                for _ in 0..8 {
                    let last = read(
                        &mut worker.client,
                        &worker.read,
                        stats,
                        false,
                        total,
                        worker.replay,
                    )?;
                    require(
                        first == last,
                        "checkpoint stress repeatable-read snapshot changed",
                    )?;
                }
                worker.client.batch_execute("COMMIT")?;
            }
            stats.commits += 1;
        }
        Actor::Applier => {
            worker.client.batch_execute("BEGIN")?;
            let (applied, removed): (i64, i64) =
                if worker.combined_maintenance && !stats.attempts.is_multiple_of(2) {
                    let row = worker.client.query_one(&worker.combined, &[])?;
                    (row.try_get(0)?, row.try_get(1)?)
                } else {
                    let applied = worker.client.query_one(&worker.apply, &[])?.try_get(0)?;
                    let removed = if stats.attempts.is_multiple_of(2) {
                        0
                    } else {
                        worker.client.query_one(&worker.prune, &[])?.try_get(0)?
                    };
                    (applied, removed)
                };
            require(
                applied >= 0 && (0..=4096).contains(&removed),
                "checkpoint stress invalid maintenance progress",
            )?;
            if stats.attempts.is_multiple_of(17) {
                worker.client.batch_execute("ROLLBACK")?;
                stats.rollbacks += 1;
            } else {
                worker.client.batch_execute("COMMIT")?;
                stats.commits += 1;
                stats.pruned += removed as u64;
            }
        }
        Actor::Pruner => {
            let removed: i64 = worker.client.query_one(&worker.prune, &[])?.try_get(0)?;
            require(
                (0..=4096).contains(&removed),
                "checkpoint stress invalid prune count",
            )?;
            stats.pruned += removed as u64;
            stats.commits += 1;
        }
        Actor::Monitor => {
            keyed_check(&mut worker.client, stats, rows)?;
            if worker.monitor_vacuum && stats.attempts.is_multiple_of(10) {
                worker
                    .client
                    .batch_execute("VACUUM (ANALYZE) syntra.capture_events")?;
                worker
                    .client
                    .batch_execute("VACUUM (ANALYZE) syntra.capture_marks")?;
                worker
                    .client
                    .batch_execute("VACUUM (ANALYZE) syntra.capture_checkpoints")?;
                worker
                    .client
                    .batch_execute("VACUUM (ANALYZE) syntra.capture_chunks")?;
                stats.vacuums += 4;
            }
            stats.commits += 1;
        }
        Actor::Vacuum => {
            worker.client.batch_execute(VACUUM)?;
            stats.vacuums += 6;
            stats.commits += 1;
        }
    }
    Ok(())
}
fn work(
    mut worker: Worker,
    start: Instant,
    deadline: Instant,
    stop: &AtomicBool,
    rows: i32,
    total: i64,
    progress: &AtomicU64,
) -> Result<Stats> {
    let rate = worker.rate;
    let mut stats = Stats::new(worker.name, start)?;
    let vacuum = matches!(worker.actor, Actor::Vacuum);
    let span = deadline.duration_since(start);
    stats.planned = if vacuum {
        span.as_secs() / VACUUM_INTERVAL.as_secs()
    } else {
        rate * span.as_secs()
    };
    let mut next = 0;

    // unslop-ignore N_PLUS_ONE_IN_LOOP -- Each cycle is an independent concurrent database operation under correctness stress; batching changes the workload.
    while Instant::now() < deadline && !stop.load(Ordering::Acquire) {
        let scheduled = if vacuum {
            let target = start + VACUUM_INTERVAL * u32::try_from(stats.attempts)?;
            while Instant::now() < target && !stop.load(Ordering::Acquire) {
                thread::sleep(
                    target
                        .saturating_duration_since(Instant::now())
                        .min(Duration::from_millis(10)),
                );
            }
            if stop.load(Ordering::Acquire) || Instant::now() >= deadline {
                break;
            }
            target
        } else if rate == 0 {
            Instant::now()
        } else {
            let target = start + arrival_offset(next, rate)?;
            while Instant::now() < target && !stop.load(Ordering::Acquire) {
                thread::sleep(
                    target
                        .saturating_duration_since(Instant::now())
                        .min(Duration::from_millis(10)),
                );
            }
            if stop.load(Ordering::Acquire) || Instant::now() >= deadline {
                break;
            }
            let slot = checkpoint_due_slot(next, start.elapsed(), rate, stats.planned)?;
            if slot == stats.planned {
                break;
            }
            next = slot + 1;
            start + arrival_offset(slot, rate)?
        };
        stats.attempts += 1;
        let cycle_start = Instant::now();
        match cycle(&mut worker, &mut stats, rows, total) {
            Ok(()) => {
                stats
                    .latency
                    .record_us(u64::try_from(cycle_start.elapsed().as_micros())?)?;
                stats
                    .scheduled_latency
                    .record_us(u64::try_from(scheduled.elapsed().as_micros())?)?;
            }
            Err(error) => {
                let expected = error
                    .downcast_ref::<postgres::Error>()
                    .and_then(|e| rejection(e, worker.actor));
                if let Some(reason) = expected {
                    worker.client.batch_execute("ROLLBACK")?;
                    *stats.rejections.entry(reason).or_default() += 1;
                    stats
                        .rejected_latency
                        .record_us(u64::try_from(cycle_start.elapsed().as_micros())?)?;
                    stats
                        .scheduled_rejected_latency
                        .record_us(u64::try_from(scheduled.elapsed().as_micros())?)?;
                } else {
                    return Err(error);
                }
            }
        }
        progress.store(stats.commits, Ordering::Release);
    }
    while worker.hold_until_stop && !stop.load(Ordering::Acquire) {
        thread::sleep(Duration::from_millis(10));
    }
    require(
        stats.commits > 0,
        "checkpoint stress worker made no committed progress",
    )?;
    Ok(stats)
}
struct StopOnExit<'a>(&'a AtomicBool);
impl Drop for StopOnExit<'_> {
    fn drop(&mut self) {
        self.0.store(true, Ordering::Release);
    }
}
fn footprint(client: &mut Client) -> Result<Value> {
    Ok(client.query_one("SELECT json_build_object('source_bytes',pg_total_relation_size('checkpoint_stress_source'),'checkpoint_catalog_bytes',pg_total_relation_size('syntra.capture_checkpoints')+pg_total_relation_size('syntra.capture_chunks'),'checkpoint_manifest_bytes',pg_total_relation_size('syntra.capture_checkpoints'),'checkpoint_chunk_bytes',pg_total_relation_size('syntra.capture_chunks'),'event_catalog_bytes',pg_total_relation_size('syntra.capture_events'),'base_catalog_bytes',pg_total_relation_size('syntra.capture_base_rows'),'head_catalog_bytes',pg_total_relation_size('syntra.capture_heads'),'wal_lsn',pg_current_wal_insert_lsn()::text,'emitted',h.emitted,'pruned',h.pruned,'applied',c.applied,'generation',c.generation,'retained_events',(SELECT count(*) FROM syntra.capture_events WHERE source_relation=h.source_relation)) FROM (SELECT hh.source_relation,hh.epoch,hh.base_rows,hh.pruned,coalesce(m.ordinal,hh.emitted) AS emitted,coalesce(m.live_rows,hh.live_rows) AS live_rows FROM syntra.capture_heads AS hh LEFT JOIN LATERAL (SELECT ordinal,live_rows FROM syntra.capture_marks WHERE epoch=hh.epoch AND ordinal>hh.emitted ORDER BY ordinal DESC LIMIT 1) AS m ON true) AS h JOIN syntra.capture_checkpoints AS c USING(source_relation,epoch) WHERE h.source_relation='checkpoint_stress_source'::regclass LIMIT 1",&[])?.try_get(0)?)
}
pub(super) fn run(cluster: &Cluster, options: &Options) -> Result<Value> {
    let soak = options.checkpoint_soak_seconds > 0;
    let seconds = if soak {
        options.checkpoint_soak_seconds
    } else {
        options.checkpoint_stress_seconds
    };
    eprintln!(
        "Checkpoint {}: {seconds} seconds, {} workers and one retained snapshot",
        if soak { "soak" } else { "concurrency stress" },
        if soak { 9 } else { 8 }
    );
    let rows = options.rows.clamp(4, 100000);
    let mut admin = cluster.connect("syntra_enabled")?;
    admin.batch_execute("SET statement_timeout='15s'; SET lock_timeout='5s'; CREATE TABLE checkpoint_stress_source(id int4 PRIMARY KEY,v int4); CREATE ROLE checkpoint_stress_reader NOLOGIN; GRANT SELECT ON checkpoint_stress_source TO checkpoint_stress_reader")?;
    admin.execute("INSERT INTO checkpoint_stress_source(id,v) SELECT n,CASE WHEN n%17=0 THEN NULL ELSE 1000000+n END FROM generate_series(1,$1::int4) AS n",&[&rows])?;
    admin.query_one(
        "SELECT syntra_seed_capture('checkpoint_stress_source','id','v',4096)",
        &[],
    )?;
    admin.query_one(APPLY, &[])?;
    let total: i64 = admin
        .query_one("SELECT sum(v) FROM checkpoint_stress_source", &[])?
        .try_get(0)?;
    let before =
        footprint(&mut admin).map_err(|e| format!("checkpoint stress initial footprint: {e}"))?;
    let mut anchor = cluster.connect("syntra_enabled")?;
    // A soak holds this snapshot until its midpoint; a stress run until the end.
    let held = if soak { seconds / 2 } else { seconds } + 30;
    anchor.query_one(
        "SELECT set_config('idle_in_transaction_session_timeout',$1,false)",
        &[&format!("{held}s")],
    )?;
    anchor.batch_execute("SET statement_timeout='15s'; SET ROLE checkpoint_stress_reader; BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY")?;
    let anchor_read = anchor.prepare(READ)?;
    let mut anchor_stats = Stats::new("retained_snapshot", Instant::now())?;
    let initial = read(
        &mut anchor,
        &anchor_read,
        &mut anchor_stats,
        false,
        total,
        options.checkpoint_reader_replay,
    )?;
    require(
        anchor_stats.routes.get("checkpoint/eligible") == Some(&1),
        "checkpoint stress initial retained snapshot was not eligible",
    )?;
    let mut workers = Vec::new();
    let mut pids = Vec::new();
    let mut actors = vec![
        (Actor::Writer(0), "writer_0"),
        (Actor::Writer(1), "writer_1"),
        (Actor::Reader(false), "read_committed"),
        (Actor::Reader(true), "repeatable_read"),
        (Actor::Applier, "applier_0"),
        (Actor::Applier, "applier_1"),
        (Actor::Pruner, "pruner"),
        (Actor::Monitor, "keyed_monitor"),
    ];
    if soak {
        actors.push((Actor::Vacuum, "vacuum"));
    }
    actors.retain(|(_, name)| !options.checkpoint_soak_skip.iter().any(|skip| skip == name));
    for (actor, name) in actors {
        let mut client = cluster.connect("syntra_enabled")?;
        client.batch_execute("SET statement_timeout='15s'; SET lock_timeout='250ms'; SET idle_in_transaction_session_timeout='20s'")?;
        if matches!(actor, Actor::Vacuum) {
            client.batch_execute("SET statement_timeout='60s'; SET lock_timeout='5s'")?;
        }
        pids.push(
            client
                .query_one("SELECT pg_backend_pid()", &[])?
                .try_get::<_, i32>(0)?,
        );
        if matches!(actor, Actor::Reader(_)) {
            client.batch_execute("SET ROLE checkpoint_stress_reader")?;
        }
        let read = client.prepare(READ)?;
        let transfer = client.prepare(TRANSFER)?;
        let apply = client.prepare(APPLY)?;
        let prune = client.prepare(PRUNE)?;
        let combined = client.prepare(COMBINED)?;
        workers.push(Worker {
            replay: options.checkpoint_reader_replay,
            client,
            actor,
            read,
            transfer,
            apply,
            prune,
            combined,
            combined_maintenance: options.checkpoint_combined_maintenance,
            monitor_vacuum: !soak,
            hold_until_stop: soak,
            rate: options.checkpoint_worker_rate,
            name,
        });
    }
    eprintln!("Checkpoint stress: setup complete; starting workers");
    let names: Vec<&'static str> = workers.iter().map(|w| w.name).collect();
    let progress: Vec<AtomicU64> = workers.iter().map(|_| AtomicU64::new(0)).collect();
    let mut windows = Vec::new();
    let stop = AtomicBool::new(false);
    let start = Instant::now();
    let deadline = start + Duration::from_secs(seconds);
    let reports = thread::scope(|scope| -> Result<Vec<Stats>> {
        let mut handles = Vec::new();
        for (worker, progress) in workers.into_iter().zip(&progress) {
            let stop = &stop;
            let name = worker.name;
            match thread::Builder::new()
                .name(name.into())
                .spawn_scoped(scope, move || {
                    let _stop = StopOnExit(stop);
                    work(worker, start, deadline, stop, rows, total, progress)
                        .map_err(|e| format!("{name}: {e}"))
                }) {
                Ok(handle) => handles.push(handle),
                Err(e) => {
                    stop.store(true, Ordering::Release);
                    return Err(e.into());
                }
            }
        }
        let mut failure = None;
        if soak {
            let sampler = crate::checkpoint_soak::Sampler {
                names: &names,
                pids: &pids,
                progress: &progress,
                start,
                window: Duration::from_secs(options.checkpoint_soak_window_seconds),
                windows: seconds / options.checkpoint_soak_window_seconds,
                disk_budget_bytes: options.checkpoint_soak_disk_budget_mb * 1024 * 1024,
                stop: &stop,
            };
            let observed = sampler.observe(&mut admin, &mut windows, || {
                let retained = read(
                    &mut anchor,
                    &anchor_read,
                    &mut anchor_stats,
                    false,
                    total,
                    options.checkpoint_reader_replay,
                )?;
                require(
                    retained == initial
                        && anchor_stats.routes.get("checkpoint/eligible") == Some(&2),
                    "checkpoint soak lost its retained checkpoint snapshot",
                )?;
                anchor.batch_execute("COMMIT")?;
                eprintln!("Checkpoint soak: retained snapshot verified and released");
                Ok(())
            });
            stop.store(true, Ordering::Release);
            if let Err(e) = observed {
                failure = Some(format!("soak sampler: {e}"));
            }
        }
        let mut reports = Vec::new();
        for handle in handles {
            match handle.join() {
                Ok(Ok(stats)) => reports.push(stats),
                Ok(Err(e)) => {
                    failure.get_or_insert(e);
                    stop.store(true, Ordering::Release);
                }
                Err(_) => {
                    failure.get_or_insert_with(|| "checkpoint stress worker panicked".into());
                    stop.store(true, Ordering::Release);
                }
            }
        }
        if let Some(e) = failure {
            return Err(e.into());
        }
        Ok(reports)
    })?;
    let elapsed = start.elapsed().as_secs_f64();
    eprintln!("Checkpoint stress: workers joined after {elapsed:.3}s");
    require(
        reports
            .iter()
            .filter(|s| s.name.starts_with("writer") || s.name.starts_with("applier"))
            .all(|s| s.rollbacks > 0),
        "checkpoint stress did not exercise intentional rollbacks",
    )?;
    require(
        reports.iter().map(|s| s.pruned).sum::<u64>() > 0
            && reports.iter().any(|s| s.keyed_checks > 0)
            && reports.iter().any(|s| s.vacuums > 0),
        "checkpoint stress did not exercise pruning, keyed checks and vacuum",
    )?;
    require(
        reports.iter().any(|s| s.name == "pruner" && s.pruned > 0),
        "checkpoint stress independent pruner deleted no events",
    )?;
    let after =
        footprint(&mut admin).map_err(|e| format!("checkpoint stress terminal footprint: {e}"))?;
    let committed_writes = reports
        .iter()
        .filter(|s| s.name.starts_with("writer"))
        .map(|s| s.commits)
        .sum::<u64>();
    let pruned_events = reports.iter().map(|s| s.pruned).sum::<u64>();
    require(
        after["emitted"].as_u64() == Some(committed_writes * 6)
            && after["pruned"].as_u64() == Some(pruned_events)
            && after["retained_events"].as_i64()
                == after["emitted"]
                    .as_i64()
                    .zip(after["pruned"].as_i64())
                    .map(|(emitted, pruned)| emitted - pruned),
        "checkpoint stress capture or pruning accounting disagreed with committed operations",
    )?;
    require(
        after["emitted"].as_i64().is_some_and(|n| n > 4096)
            && after["generation"].as_i64().is_some_and(|n| n > 1),
        "checkpoint stress did not advance beyond the original event budget",
    )?;
    if !soak {
        require(
            read(
                &mut anchor,
                &anchor_read,
                &mut anchor_stats,
                false,
                total,
                options.checkpoint_reader_replay,
            )? == initial
                && anchor_stats.routes.get("checkpoint/eligible") == Some(&2),
            "checkpoint stress lost its retained checkpoint snapshot",
        )?;
        anchor
            .batch_execute("COMMIT")
            .map_err(|e| format!("checkpoint stress release retained snapshot: {e}"))?;
    }
    eprintln!("Checkpoint stress: retained snapshot verified; draining checkpoint");
    let wal: String = admin
        .query_one(
            "SELECT pg_wal_lsn_diff($1::text::pg_lsn,$2::text::pg_lsn)::text",
            &[
                &after["wal_lsn"].as_str().ok_or("missing final WAL LSN")?,
                &before["wal_lsn"]
                    .as_str()
                    .ok_or("missing initial WAL LSN")?,
            ],
        )?
        .try_get(0)?;
    let soak_report = if soak {
        let wal_bytes: u64 = wal.parse()?;
        let service = reports
            .iter()
            .filter(|s| {
                matches!(
                    s.name,
                    "writer_0" | "writer_1" | "read_committed" | "repeatable_read"
                )
            })
            .map(|s| crate::checkpoint_soak::Service {
                name: s.name,
                scheduled_p99_ms: s.scheduled_latency.report()["p99_ms"]
                    .as_f64()
                    .unwrap_or(f64::MAX),
                planned: s.planned,
                missed: s.planned.saturating_sub(s.attempts),
            })
            .collect::<Vec<_>>();
        crate::checkpoint_soak::evaluate(&windows, &service, wal_bytes, committed_writes)?
    } else {
        Value::Null
    };
    admin
        .query_one(APPLY, &[])
        .map_err(|e| format!("checkpoint stress final apply: {e}"))?;
    admin
        .query_one(PRUNE, &[])
        .map_err(|e| format!("checkpoint stress final prune: {e}"))?;
    let mut final_stats = Stats::new("quiescent", Instant::now())?;
    keyed_check(&mut admin, &mut final_stats, rows)?;
    let final_read = admin.prepare(READ)?;
    read(
        &mut admin,
        &final_read,
        &mut final_stats,
        false,
        total,
        options.checkpoint_reader_replay,
    )?;
    require(
        final_stats.routes.get("checkpoint/eligible") == Some(&1),
        "checkpoint reuse failed after stress drain",
    )?;
    let drained =
        footprint(&mut admin).map_err(|e| format!("checkpoint stress drained footprint: {e}"))?;
    require(
        drained["emitted"] == drained["applied"]
            && drained["emitted"] == drained["pruned"]
            && drained["retained_events"] == 0,
        "checkpoint stress drain left pending events",
    )?;
    eprintln!("Checkpoint stress: checkpoint drained; running final vacuum");
    admin
        .batch_execute("VACUUM (ANALYZE) checkpoint_stress_source")
        .map_err(|e| format!("checkpoint stress final source vacuum: {e}"))?;
    admin.batch_execute("VACUUM (ANALYZE) syntra.capture_events")?;
    admin.batch_execute("VACUUM (ANALYZE) syntra.capture_marks")?;
    admin.batch_execute("VACUUM (ANALYZE) syntra.capture_checkpoints")?;
    admin.batch_execute("VACUUM (ANALYZE) syntra.capture_chunks")?;
    admin.batch_execute("VACUUM (ANALYZE) syntra.capture_heads")?;
    let vacuumed =
        footprint(&mut admin).map_err(|e| format!("checkpoint stress vacuumed footprint: {e}"))?;
    admin
        .batch_execute("DROP TABLE checkpoint_stress_source; DROP ROLE checkpoint_stress_reader")?;
    require(
        options.checkpoint_soak_skip.is_empty(),
        "ablated soak is diagnostic only; read the per-window samples, no report is written",
    )?;
    Ok(
        json!({"duration_seconds":seconds,"soak":soak_report,"elapsed_including_drain_seconds":elapsed,"source_rows":rows,"capture_event_budget":4096,"reader_tail_opt_in":options.checkpoint_reader_replay,"combined_maintenance":options.checkpoint_combined_maintenance,"offered_cycles_per_worker_second":options.checkpoint_worker_rate,"arrival_policy":"zero rate is saturated; otherwise absolute slots, drop missed slots, no catch-up burst","workers":reports.iter().map(Stats::report).collect::<Vec<_>>(),"retained_snapshot_checks":anchor_stats.checks,"quiescent_keyed_check":true,"quiescent_checkpoint_reuse":true,"unexpected_errors":0,"invariant_failures":0,"before":before,"after":after,"after_drain":drained,"after_vacuum":vacuumed,"wal_bytes":wal,"scope":if soak {"paced correctness soak; independent sessions and vacuum worker; one old snapshot retained until the midpoint; per-window progress, storage, WAL, xmin horizon and backend RSS samples; RSS includes touched shared buffers; WAL excludes final drain/vacuum; no cross-database speed claim"} else {"correctness stress; optional paced per-worker arrivals; independent sessions; successful and rejected cycle service latencies; WAL excludes final drain/vacuum; one old snapshot retained throughout; no RSS quota, disk reclamation or cross-database speed claim"}}),
    )
}
