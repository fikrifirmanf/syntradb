//! Source capture uses the caller's active MVCC snapshot and a locked relation.
//! All new manual PostgreSQL FFI for source reads is confined to this module.
use pgrx::prelude::*;
use pgrx::PgRelation;
use std::ffi::CStr;
use std::marker::PhantomData;
use syntra_storage::SegmentError;

fn unsupported(message: &'static str) -> ! {
    pgrx::ereport!(
        ERROR,
        pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
        message
    );
}

/// The relation guard, active snapshot, scan and slot all stay on one backend.
/// The lifetime prevents the scan from outliving its AccessShare-locked source.
struct SourceScan<'a> {
    scan: pg_sys::TableScanDesc,
    slot: *mut pg_sys::TupleTableSlot,
    attribute: i16,
    _relation: PhantomData<&'a PgRelation>,
}

impl<'a> SourceScan<'a> {
    fn new(relation: &'a PgRelation, attribute: i16, snapshot: pg_sys::Snapshot) -> Self {
        Self::with_predicate(
            relation,
            attribute,
            snapshot,
            syntra_exec::Int4Predicate::All,
        )
    }

    fn with_predicate(
        relation: &'a PgRelation,
        attribute: i16,
        snapshot: pg_sys::Snapshot,
        predicate: syntra_exec::Int4Predicate,
    ) -> Self {
        // SAFETY: the caller validates a heap relation, positive int4 attribute,
        // and active MVCC snapshot. PgRelation holds AccessShareLock for 'a.
        // Scan state never escapes the backend; PostgreSQL owns its allocations.
        unsafe {
            let mut keys = [pg_sys::ScanKeyData::default(); 2];
            let nkeys = if let syntra_exec::Int4Predicate::Range { lower, upper } = predicate {
                // Native heap keys apply the same built-in int4 comparisons as
                // BETWEEN, excluding NULLs. heap_beginscan copies these keys into
                // scan-owned memory; int4 arguments are by-value Datums.
                pg_sys::ScanKeyInit(
                    &mut keys[0],
                    attribute,
                    pg_sys::BTGreaterEqualStrategyNumber as u16,
                    pg_sys::Oid::from(pg_sys::F_INT4GE),
                    pg_sys::Datum::from(lower),
                );
                pg_sys::ScanKeyInit(
                    &mut keys[1],
                    attribute,
                    pg_sys::BTLessEqualStrategyNumber as u16,
                    pg_sys::Oid::from(pg_sys::F_INT4LE),
                    pg_sys::Datum::from(upper),
                );
                2
            } else {
                0
            };
            let scan = pg_sys::table_beginscan(
                relation.as_ptr(),
                snapshot,
                nkeys,
                if nkeys == 0 {
                    std::ptr::null_mut()
                } else {
                    keys.as_mut_ptr()
                },
            );
            let slot = pg_sys::table_slot_create(relation.as_ptr(), std::ptr::null_mut());
            Self {
                scan,
                slot,
                attribute,
                _relation: PhantomData,
            }
        }
    }
}

impl Iterator for SourceScan<'_> {
    type Item = Option<i32>;

    fn next(&mut self) -> Option<Self::Item> {
        // SAFETY: scan/slot belong to the same locked table and are live until
        // Drop. The checked attribute is an int4 column in that table's descriptor.
        // FromDatum copies the by-value integer; no tuple pointer is retained.
        unsafe {
            if !pg_sys::table_scan_getnextslot(
                self.scan,
                pg_sys::ScanDirection::ForwardScanDirection,
                self.slot,
            ) {
                return None;
            }
            let mut is_null = false;
            let value = pg_sys::slot_getattr(self.slot, i32::from(self.attribute), &mut is_null);
            Some(i32::from_datum(value, is_null))
        }
    }
}

impl Drop for SourceScan<'_> {
    fn drop(&mut self) {
        // SAFETY: one owner, same backend thread, and no outstanding tuple borrows.
        // Releasing the slot first also releases its buffer pins before scan end.
        unsafe {
            pg_sys::ExecDropSingleTupleTableSlot(self.slot);
            pg_sys::table_endscan(self.scan);
        }
    }
}

struct Provenance {
    database: pg_sys::Oid,
    snapshot: String,
    transaction: Option<String>,
    command: i64,
    captured_at: TimestampWithTimeZone,
    active_snapshot: pg_sys::Snapshot,
}

pub(super) fn source_snapshot() -> pg_sys::Snapshot {
    // SAFETY: backend main thread, called while the SQL function is executing.
    // The active snapshot stays owned by PostgreSQL throughout the native scan.
    unsafe {
        let snapshot = pg_sys::GetActiveSnapshot();
        if snapshot.is_null() || (*snapshot).snapshot_type != pg_sys::SnapshotType::SNAPSHOT_MVCC {
            unsupported("source capture requires an active MVCC snapshot");
        }
        if pg_sys::XactIsoLevel == pg_sys::XACT_SERIALIZABLE as i32 {
            unsupported("serializable source capture is not supported yet");
        }
        snapshot
    }
}

/// Bounded keyed seed scan. Caller owns the source's exclusive transaction lock
/// and an active snapshot obtained after that lock was granted.
pub(super) fn keyed_seed(
    source: &PgRelation,
    key: i16,
    value: i16,
    snapshot: pg_sys::Snapshot,
) -> Vec<syntra_storage::replay::Row> {
    let mut scan = SourceScan::new(source, value, snapshot);
    let mut rows = Vec::new();
    rows.try_reserve_exact(100_000).unwrap_or_else(|_| {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_OUT_OF_MEMORY,
            "cannot allocate capture seed"
        );
    });
    while let Some(value) = scan.next() {
        if rows.len() == 100_000 {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_PROGRAM_LIMIT_EXCEEDED,
                "capture seed exceeds 100000 rows"
            );
        }
        // SAFETY: the live scan slot still holds the tuple just yielded. The
        // caller validated a non-NULL int4 primary key under an exclusive lock.
        let key = unsafe {
            let mut null = false;
            let datum = pg_sys::slot_getattr(scan.slot, i32::from(key), &mut null);
            if null {
                pgrx::error!("capture primary key is NULL");
            }
            i32::from_datum(datum, false)
                .unwrap_or_else(|| pgrx::error!("capture primary key is invalid"))
        };
        rows.push(syntra_storage::replay::Row { key, value });
    }
    rows.sort_unstable_by_key(|row| row.key);
    pgrx::check_for_interrupts!();
    rows
}

fn provenance() -> Provenance {
    // SAFETY: invoked only by a parallel-unsafe SQL function on the backend main
    // thread. Direct calls use PostgreSQL's typed builtins and do not run SPI or
    // acquire a different snapshot. Snapshot storage stays active until SQL return.
    unsafe {
        let snapshot = source_snapshot();
        let datum = pgrx::direct_function_call_as_datum(pg_sys::pg_current_snapshot, &[])
            .unwrap_or_else(|| pgrx::error!("cannot obtain source snapshot"));
        let text = pgrx::direct_function_call::<&CStr>(pg_sys::pg_snapshot_out, &[Some(datum)])
            .unwrap_or_else(|| pgrx::error!("cannot describe source snapshot"));
        let captured_at =
            pgrx::direct_function_call::<TimestampWithTimeZone>(pg_sys::statement_timestamp, &[])
                .unwrap_or_else(|| pgrx::error!("cannot obtain capture statement timestamp"));
        let transaction = pg_sys::GetCurrentFullTransactionIdIfAny().value;
        Provenance {
            database: pg_sys::MyDatabaseId,
            snapshot: text.to_string_lossy().into_owned(),
            transaction: (transaction != 0).then(|| transaction.to_string()),
            command: i64::from((*snapshot).curcid),
            captured_at,
            active_snapshot: snapshot,
        }
    }
}

pub(super) fn validate_source(relation: &PgRelation, column: &str) -> i16 {
    // SAFETY: PgRelation was opened by pgrx's REGCLASS adapter with AccessShareLock.
    // Catalog and ACL calls remain in its owning backend. Check permissions before
    // inspecting user column metadata; raw table scans do not enforce SQL ACL/RLS.
    unsafe {
        let role = pg_sys::GetUserId();
        if pg_sys::object_aclcheck(
            pg_sys::NamespaceRelationId,
            relation.namespace_oid(),
            role,
            pg_sys::ACL_USAGE.into(),
        ) != pg_sys::AclResult::ACLCHECK_OK
            || pg_sys::pg_class_aclcheck(relation.oid(), role, pg_sys::ACL_SELECT.into())
                != pg_sys::AclResult::ACLCHECK_OK
        {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_INSUFFICIENT_PRIVILEGE,
                "source capture requires schema USAGE and table SELECT privileges"
            );
        }
        let catalog = &*relation.rd_rel;
        if catalog.relkind as u8 != pg_sys::RELKIND_RELATION
            || catalog.relam != pg_sys::HEAP_TABLE_AM_OID
            || catalog.relispartition
            || catalog.relhassubclass
        {
            unsupported("source capture supports only ordinary heap tables without partitions or descendants");
        }
        if catalog.relrowsecurity || catalog.relforcerowsecurity {
            unsupported("source capture does not support row-level security");
        }
    }
    let descriptor = relation.tuple_desc();
    let attribute = descriptor
        .iter()
        .find(|attribute| {
            !attribute.attisdropped && pgrx::name_data_to_str(&attribute.attname) == column
        })
        .unwrap_or_else(|| {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_UNDEFINED_COLUMN,
                "source column does not exist"
            );
        });
    if attribute.atttypid != pg_sys::INT4OID || attribute.attgenerated != 0 || attribute.attnum <= 0
    {
        unsupported("source capture requires a stored, non-generated int4 column");
    }
    // SAFETY: the argument adapter already holds AccessShareLock. Retain an
    // additional reference until transaction end: PgRelation drops its own lock
    // at function return, but repeated reads must stay protected from DDL just
    // like a native table reference. PostgreSQL releases this reference on abort
    // or commit; no Rust-owned pointer or manual unlock escapes this function.
    unsafe { pg_sys::LockRelationOid(relation.oid(), pg_sys::AccessShareLock as i32) };
    attribute.attnum
}

pub(super) type SummaryRow = (i64, i64, Option<i64>, Option<i32>, Option<i32>);

fn heap_summary(
    source: &PgRelation,
    column: &str,
    predicate: syntra_exec::Int4Predicate,
) -> SummaryRow {
    let attribute = validate_source(source, column);
    heap_summary_checked(source, attribute, source_snapshot(), predicate)
}

pub(super) fn heap_summary_checked(
    source: &PgRelation,
    attribute: i16,
    snapshot: pg_sys::Snapshot,
    predicate: syntra_exec::Int4Predicate,
) -> SummaryRow {
    let rows = SourceScan::with_predicate(source, attribute, snapshot, predicate);
    let summary = syntra_exec::summarize_int4_where(rows, predicate, || {
        pgrx::check_for_interrupts!();
        true
    })
    .unwrap_or_else(|error| {
        let code = match error {
            syntra_exec::ExecutionError::Aggregate(_) => {
                pgrx::PgSqlErrorCode::ERRCODE_NUMERIC_VALUE_OUT_OF_RANGE
            }
            syntra_exec::ExecutionError::Cancelled => pgrx::PgSqlErrorCode::ERRCODE_QUERY_CANCELED,
            syntra_exec::ExecutionError::Segment(_) => pgrx::PgSqlErrorCode::ERRCODE_INTERNAL_ERROR,
        };
        pgrx::ereport!(ERROR, code, error.to_string());
    });
    (
        summary.rows(),
        summary.non_nulls(),
        summary.sum(),
        summary.min(),
        summary.max(),
    )
}

pub(super) fn encode_source(
    source: &PgRelation,
    attribute: i16,
    snapshot: pg_sys::Snapshot,
) -> Result<(Vec<u8>, u32), SegmentError> {
    syntra_storage::encode_int4_with_row_count(SourceScan::new(source, attribute, snapshot), || {
        pgrx::check_for_interrupts!();
        true
    })
}

/// Fresh aggregate over the caller's snapshot. No segment or cache is created.
#[allow(clippy::type_complexity)]
#[pg_extern(stable, parallel_unsafe)]
fn syntra_heap_int4_summary(
    source: PgRelation,
    column: &str,
) -> TableIterator<
    'static,
    (
        name!(rows, i64),
        name!(non_nulls, i64),
        name!(sum, Option<i64>),
        name!(min, Option<i32>),
        name!(max, Option<i32>),
    ),
> {
    TableIterator::new(std::iter::once(heap_summary(
        &source,
        column,
        syntra_exec::Int4Predicate::All,
    )))
}

/// Inclusive BETWEEN semantics, with interrupt checks on all examined rows.
#[allow(clippy::type_complexity)]
#[pg_extern(stable, parallel_unsafe)]
fn syntra_heap_int4_range_summary(
    source: PgRelation,
    column: &str,
    lower: i32,
    upper: i32,
) -> TableIterator<
    'static,
    (
        name!(rows, i64),
        name!(non_nulls, i64),
        name!(sum, Option<i64>),
        name!(min, Option<i32>),
        name!(max, Option<i32>),
    ),
> {
    TableIterator::new(std::iter::once(heap_summary(
        &source,
        column,
        syntra_exec::Int4Predicate::Range { lower, upper },
    )))
}

/// Current locked storage identity, not an MVCC catalog row or a freshness proof.
/// Relcache invalidation makes storage replacement observable to old snapshots.
#[allow(clippy::type_complexity)]
#[pg_extern(volatile, parallel_unsafe)]
fn syntra_source_identity(
    source: PgRelation,
    column: &str,
) -> TableIterator<
    'static,
    (
        name!(cluster_identity, String),
        name!(source_database, pg_sys::Oid),
        name!(source_relation, pg_sys::Oid),
        name!(storage_tablespace, pg_sys::Oid),
        name!(storage_database, Option<pg_sys::Oid>),
        name!(storage_file, pg_sys::Oid),
        name!(source_attribute, i16),
        name!(source_type, pg_sys::Oid),
        name!(type_modifier, i32),
        name!(source_collation, Option<pg_sys::Oid>),
        name!(access_method, pg_sys::Oid),
    ),
> {
    let attribute = validate_source(&source, column);
    let descriptor = source.tuple_desc();
    let field = descriptor
        .iter()
        .find(|field| field.attnum == attribute)
        .unwrap_or_else(|| pgrx::error!("locked source attribute disappeared"));
    // SAFETY: PgRelation holds AccessShareLock, preventing a concurrent rewrite
    // until this transaction releases it. Copy only scalar descriptor/locator
    // fields. The cluster control identifier is initialized before backend use.
    let (cluster, database, locator, method) = unsafe {
        (
            pg_sys::GetSystemIdentifier().to_string(),
            pg_sys::MyDatabaseId,
            source.rd_locator,
            (*source.rd_rel).relam,
        )
    };
    TableIterator::new(std::iter::once((
        cluster,
        database,
        source.oid(),
        locator.spcOid,
        (locator.dbOid != pg_sys::InvalidOid).then_some(locator.dbOid),
        locator.relNumber,
        attribute,
        field.atttypid,
        field.atttypmod,
        (field.attcollation != pg_sys::InvalidOid).then_some(field.attcollation),
        method,
    )))
}

/// Capture directly from a checked source. This fixed artifact is never eligible
/// for automatic live-table substitution, regardless of matching snapshot text.
// Concrete named columns are required by pgrx schema generation.
#[allow(clippy::type_complexity)]
#[pg_extern(stable, parallel_unsafe)]
fn syntra_capture_int4(
    source: PgRelation,
    column: &str,
) -> TableIterator<
    'static,
    (
        name!(segment, Vec<u8>),
        name!(source_database, pg_sys::Oid),
        name!(source_relation, pg_sys::Oid),
        name!(source_schema, String),
        name!(source_table, String),
        name!(source_column, String),
        name!(source_attribute, i16),
        name!(source_type, pg_sys::Oid),
        name!(source_snapshot, String),
        name!(source_transaction, Option<String>),
        name!(source_command, i64),
        name!(captured_at, TimestampWithTimeZone),
        name!(source_rows, i64),
    ),
> {
    let attribute = validate_source(&source, column);
    let provenance = provenance();
    let rows = SourceScan::new(&source, attribute, provenance.active_snapshot);
    let (segment, count) = syntra_storage::encode_int4_with_row_count(rows, || {
        pgrx::check_for_interrupts!();
        true
    })
    .unwrap_or_else(|error| {
        let code = match error {
            SegmentError::LimitExceeded => pgrx::PgSqlErrorCode::ERRCODE_PROGRAM_LIMIT_EXCEEDED,
            SegmentError::AllocationFailed => pgrx::PgSqlErrorCode::ERRCODE_OUT_OF_MEMORY,
            _ => pgrx::PgSqlErrorCode::ERRCODE_QUERY_CANCELED,
        };
        pgrx::ereport!(ERROR, code, error.to_string());
    });
    TableIterator::new(std::iter::once((
        segment,
        provenance.database,
        source.oid(),
        source.namespace().to_owned(),
        source.name().to_owned(),
        column.to_owned(),
        attribute,
        pg_sys::INT4OID,
        provenance.snapshot,
        provenance.transaction,
        provenance.command,
        provenance.captured_at,
        i64::from(count),
    )))
}
