use super::*;
use crate::native_catalog::int2_key;
use std::sync::atomic::{AtomicU64, Ordering};
use syntra_storage::chunks::{chunk_binding, digest, partition, ChunkRef, Manifest, PARTITIONS};
pub(super) struct Chunk {
    index: usize,
    state: Option<Vec<u8>>,
    segment: Option<Vec<u8>>,
}
// Backend-local observation of the latest chunk pass. Backends are single-threaded;
// atomics avoid unsafe statics. Values are reset when a pass starts.
static PASS_CHUNKS: AtomicU64 = AtomicU64::new(0);
static PASS_BYTES: AtomicU64 = AtomicU64::new(0);
static PASS_PEAK: AtomicU64 = AtomicU64::new(0);
/// (chunks passed to the caller, stored bytes fetched including a chunk that then
/// failed its digest, largest bytes held at once).
pub(super) fn last_pass() -> (u64, u64, u64) {
    (
        PASS_CHUNKS.load(Ordering::Relaxed),
        PASS_BYTES.load(Ordering::Relaxed),
        PASS_PEAK.load(Ordering::Relaxed),
    )
}
/// Streams referenced chunks one at a time; `each` owns that chunk's bytes, which
/// are dropped before the next partition is read. Stored lengths must equal the
/// manifest row count's exact encoding before any bytes are fetched or detoasted.
fn visit(
    source: &PgRelation,
    snapshot: pg_sys::Snapshot,
    manifest: &Manifest,
    states: u64,
    segments: u64,
    byte_limit: usize,
    mut each: impl FnMut(Chunk) -> Checked<()>,
) -> Checked<()> {
    for counter in [&PASS_CHUNKS, &PASS_BYTES, &PASS_PEAK] {
        counter.store(0, Ordering::Relaxed);
    }
    let keys = |index: usize| {
        [
            oid_key(1, "source_relation", source.oid()),
            int8_key(
                2,
                "epoch",
                manifest.binding.epoch as i64,
                Int8Comparison::Equal,
            ),
            int2_key(3, "partition", index as i16),
            int8_key(
                4,
                "revision",
                manifest.chunks[index].revision as i64,
                Int8Comparison::Equal,
            ),
        ]
    };
    let mut scan = CatalogScan::open(
        c"syntra",
        c"capture_chunks",
        c"capture_chunks_version_index",
        snapshot,
        &keys(0),
    )
    .ok_or("checkpoint_metadata_missing")?;
    let mut input_bytes = 0_usize;
    // Fixed 64 native index probes share one scan; no per-partition SQL requests.
    for index in 0..PARTITIONS {
        scan.rescan(&keys(index))
            .ok_or("checkpoint_chunk_index_unavailable")?;
        let row = scan.next().ok_or("invalid_checkpoint")?;
        let bit = 1_u64 << index;
        let reference = &manifest.chunks[index];
        if row.get::<pg_sys::Oid>(1, "source_relation") != Some(source.oid())
            || row.get::<i64>(2, "epoch") != Some(manifest.binding.epoch as i64)
            || row.get::<i16>(3, "partition") != Some(index as i16)
            || row.get::<i64>(4, "revision") != Some(reference.revision as i64)
            || row.get::<i64>(5, "row_count") != Some(i64::from(reference.rows))
        {
            return Err("invalid_checkpoint");
        }
        let state = if states & bit != 0 {
            let len = ReplayState::encoded_checkpoint_len(reference.rows as usize)
                .map_err(|_| "invalid_checkpoint")?;
            input_bytes = super::input_bytes(input_bytes, len, byte_limit)?;
            let bytes = row
                .bytes_exact(6, "state", len)
                .ok_or("invalid_checkpoint")?;
            PASS_BYTES.fetch_add(len as u64, Ordering::Relaxed);
            if digest(&bytes, keep).map_err(|_| "invalid_checkpoint")? != reference.state_digest {
                return Err("invalid_checkpoint");
            }
            Some(bytes)
        } else {
            None
        };
        let segment = if segments & bit != 0 {
            let len = syntra_storage::encoded_int4_len(reference.rows as usize)
                .map_err(|_| "invalid_checkpoint")?;
            input_bytes = super::input_bytes(input_bytes, len, byte_limit)?;
            let bytes = row
                .bytes_exact(7, "segment", len)
                .ok_or("invalid_checkpoint")?;
            PASS_BYTES.fetch_add(len as u64, Ordering::Relaxed);
            if digest(&bytes, keep).map_err(|_| "invalid_checkpoint")? != reference.segment_digest {
                return Err("invalid_checkpoint");
            }
            Some(bytes)
        } else {
            None
        };
        if scan.next().is_some() {
            return Err("invalid_checkpoint");
        }
        let held = state.as_ref().map_or(0, Vec::len) + segment.as_ref().map_or(0, Vec::len);
        PASS_CHUNKS.fetch_add(1, Ordering::Relaxed);
        PASS_PEAK.fetch_max(held as u64, Ordering::Relaxed);
        each(Chunk {
            index,
            state,
            segment,
        })?;
    }
    Ok(())
}
fn decode(chunk: &Chunk, manifest: &Manifest) -> Checked<ReplayState> {
    let state = ReplayState::decode_checkpoint(
        chunk.state.as_deref().ok_or("invalid_checkpoint")?,
        LIMITS,
        keep,
    )
    .map_err(|_| "invalid_checkpoint")?;
    let reference = &manifest.chunks[chunk.index];
    if state.binding()
        != chunk_binding(manifest.binding, chunk.index).map_err(|_| "invalid_checkpoint")?
        || state.sequence() != reference.revision
        || state.rows().len() != reference.rows as usize
    {
        return Err("invalid_checkpoint");
    }
    for (index, row) in state.rows().iter().enumerate() {
        if index % 1024 == 0 {
            keep();
        }
        if partition(row.key) != chunk.index {
            return Err("invalid_checkpoint");
        }
    }
    representations(
        &state,
        chunk.segment.as_deref().ok_or("invalid_checkpoint")?,
    )?;
    Ok(state)
}
pub(super) fn validate(
    source: &PgRelation,
    snapshot: pg_sys::Snapshot,
    manifest: &Manifest,
) -> Checked<()> {
    visit(
        source,
        snapshot,
        manifest,
        u64::MAX,
        u64::MAX,
        usize::MAX,
        |chunk| decode(&chunk, manifest).map(drop),
    )
}
pub(super) fn summarize(
    source: &PgRelation,
    snapshot: pg_sys::Snapshot,
    manifest: &Manifest,
) -> Checked<crate::source::SummaryRow> {
    let mut result = (0_i64, 0_i64, None::<i64>, None::<i32>, None::<i32>);
    visit(
        source,
        snapshot,
        manifest,
        0,
        u64::MAX,
        usize::MAX,
        |chunk| {
            let s = summary(chunk.segment.as_deref().ok_or("invalid_checkpoint")?)?;
            if s.0 != i64::from(manifest.chunks[chunk.index].rows) {
                return Err("invalid_checkpoint");
            }
            merge_summary(&mut result, s)
        },
    )?;
    if result.0 != i64::from(manifest.rows().map_err(|_| "invalid_checkpoint")?) {
        return Err("invalid_checkpoint");
    }
    Ok(result)
}
fn merge_summary(
    result: &mut crate::source::SummaryRow,
    s: crate::source::SummaryRow,
) -> Checked<()> {
    result.0 = result.0.checked_add(s.0).ok_or("invalid_checkpoint")?;
    result.1 = result.1.checked_add(s.1).ok_or("invalid_checkpoint")?;
    if let Some(sum) = s.2 {
        result.2 = Some(
            result
                .2
                .unwrap_or(0)
                .checked_add(sum)
                .ok_or("invalid_checkpoint")?,
        );
    }
    if let Some(min) = s.3 {
        result.3 = Some(result.3.map_or(min, |old| old.min(min)));
    }
    if let Some(max) = s.4 {
        result.4 = Some(result.4.map_or(max, |old| old.max(max)));
    }
    Ok(())
}
/// Read-only reconstruction; no SPI, encoding or persistent progress update.
pub(super) fn replay(
    source: &PgRelation,
    snapshot: pg_sys::Snapshot,
    manifest: &Manifest,
    delta: &[Change],
    expected_rows: i64,
) -> Checked<crate::source::SummaryRow> {
    const MAX_ROWS: usize = 65_536;
    const MAX_BYTES: usize = 8 * 1024 * 1024;
    if delta.is_empty() || delta.len() > 256 {
        return Err("checkpoint_tail_limit");
    }
    let mut edits: [Vec<Change>; PARTITIONS] = std::array::from_fn(|_| Vec::new());
    let mut dirty = 0_u64;
    for change in delta {
        let index = partition(change.key);
        dirty |= 1_u64 << index;
        edits[index].push(*change);
    }
    let initial_rows: usize = manifest
        .chunks
        .iter()
        .enumerate()
        .filter(|(index, _)| dirty & (1_u64 << index) != 0)
        .map(|(_, c)| c.rows as usize)
        .sum();
    if initial_rows
        .checked_add(delta.len())
        .is_none_or(|n| n > MAX_ROWS)
    {
        return Err("checkpoint_tail_row_limit");
    }
    let mut result = (0_i64, 0_i64, None::<i64>, None::<i32>, None::<i32>);
    visit(
        source,
        snapshot,
        manifest,
        dirty,
        u64::MAX,
        MAX_BYTES,
        |chunk| {
            let s = if dirty & (1_u64 << chunk.index) != 0 {
                let mut state = decode(&chunk, manifest)?;
                state
                    .apply(
                        Batch {
                            binding: state.binding(),
                            previous: state.sequence(),
                            next: state
                                .sequence()
                                .checked_add(1)
                                .ok_or("checkpoint_tail_rejected")?,
                            changes: &edits[chunk.index],
                        },
                        keep,
                    )
                    .map_err(|_| "checkpoint_tail_rejected")?;
                let aggregate =
                    syntra_exec::summarize_int4(state.rows().iter().map(|r| r.value), keep)
                        .map_err(|_| "checkpoint_tail_rejected")?;
                (
                    aggregate.rows(),
                    aggregate.non_nulls(),
                    aggregate.sum(),
                    aggregate.min(),
                    aggregate.max(),
                )
            } else {
                let aggregate = summary(chunk.segment.as_deref().ok_or("invalid_checkpoint")?)?;
                if aggregate.0 != i64::from(manifest.chunks[chunk.index].rows) {
                    return Err("invalid_checkpoint");
                }
                aggregate
            };
            merge_summary(&mut result, s)
        },
    )?;
    if result.0 != expected_rows {
        return Err("checkpoint_tail_row_count");
    }
    Ok(result)
}
struct Write {
    index: i16,
    revision: i64,
    rows: i64,
    state: Vec<u8>,
    segment: Vec<u8>,
}
fn encode(index: usize, state: &ReplayState) -> Checked<(ChunkRef, Write)> {
    let keyed = state
        .encode_checkpoint(keep)
        .map_err(|_| "checkpoint encoding failed")?;
    let segment = syntra_storage::encode_int4(state.rows().iter().map(|r| r.value), keep)
        .map_err(|_| "checkpoint segment encoding failed")?;
    let reference = ChunkRef {
        revision: state.sequence(),
        rows: state.rows().len() as u32,
        state_digest: digest(&keyed, keep).map_err(|_| "checkpoint encoding failed")?,
        segment_digest: digest(&segment, keep).map_err(|_| "checkpoint encoding failed")?,
    };
    let write = Write {
        index: index as i16,
        revision: state.sequence() as i64,
        rows: state.rows().len() as i64,
        state: keyed,
        segment,
    };
    Ok((reference, write))
}
fn persist(source: &PgRelation, manifest: &Manifest, writes: Vec<Write>) -> Checked<()> {
    let mut partitions = Vec::new();
    let mut revisions = Vec::new();
    let mut rows = Vec::new();
    let mut states = Vec::new();
    let mut segments = Vec::new();
    for w in writes {
        partitions.push(w.index);
        revisions.push(w.revision);
        rows.push(w.rows);
        states.push(w.state);
        segments.push(w.segment);
    }
    // One bound bulk statement; the manifest is published only after all chunks.
    Spi::run_with_args(r#"INSERT INTO syntra.capture_chunks(source_relation,epoch,partition,revision,row_count,state,segment)
        SELECT $1,$2,p,r,n,s,v FROM unnest($3::int2[],$4::int8[],$5::int8[],$6::bytea[],$7::bytea[]) AS t(p,r,n,s,v)
        ON CONFLICT(source_relation,partition) DO UPDATE SET epoch=EXCLUDED.epoch,revision=EXCLUDED.revision,
        row_count=EXCLUDED.row_count,state=EXCLUDED.state,segment=EXCLUDED.segment"#,
        &[source.oid().into(),(manifest.binding.epoch as i64).into(),partitions.into(),revisions.into(),rows.into(),states.into(),segments.into()])
        .map_err(|_|"checkpoint chunk publication failed")?;
    let bytes = manifest.encode().map_err(|_| "invalid_checkpoint")?;
    Spi::run_with_args(r#"INSERT INTO syntra.capture_checkpoints(source_relation,epoch,applied,generation,row_count,manifest)
        VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(source_relation) DO UPDATE SET epoch=EXCLUDED.epoch,
        applied=EXCLUDED.applied,generation=EXCLUDED.generation,row_count=EXCLUDED.row_count,manifest=EXCLUDED.manifest"#,
        &[source.oid().into(),(manifest.binding.epoch as i64).into(),(manifest.applied as i64).into(),(manifest.generation as i64).into(),i64::from(manifest.rows().map_err(|_|"invalid_checkpoint")?).into(),bytes.into()])
        .map_err(|_|"checkpoint manifest publication failed")?;
    Ok(())
}
pub(super) fn seed(
    source: &PgRelation,
    config: &Configuration,
    h: &Head,
    mut state: ReplayState,
    delta: &[Change],
) -> Checked<()> {
    if !delta.is_empty() {
        state
            .apply_events(
                Batch {
                    binding: binding(config),
                    previous: 0,
                    next: h.emitted as u64,
                    changes: delta,
                },
                keep,
            )
            .map_err(|_| "checkpoint replay rejected the captured event prefix")?;
    }
    if state.rows().len() as i64 != h.rows {
        return Err("checkpoint row count disagrees with capture head");
    }
    let mut partitions: [Vec<Row>; PARTITIONS] = std::array::from_fn(|_| Vec::new());
    for (index, row) in state.rows().iter().enumerate() {
        if index % 1024 == 0 {
            keep();
        }
        partitions[partition(row.key)].push(*row);
    }
    let mut manifest = Manifest {
        binding: binding(config),
        applied: h.emitted as u64,
        generation: 1,
        chunks: [ChunkRef::default(); PARTITIONS],
    };
    let mut writes = Vec::new();
    for (index, rows) in partitions.iter().enumerate() {
        let state = ReplayState::seed(
            chunk_binding(manifest.binding, index).map_err(|_| "invalid_checkpoint")?,
            0,
            rows,
            LIMITS,
            keep,
        )
        .map_err(|_| "invalid_checkpoint")?;
        let (reference, write) = encode(index, &state)?;
        manifest.chunks[index] = reference;
        writes.push(write);
    }
    persist(source, &manifest, writes)
}
pub(super) fn advance(
    source: &PgRelation,
    snapshot: pg_sys::Snapshot,
    h: &Head,
    mut manifest: Manifest,
    delta: &[Change],
) -> Checked<()> {
    let mut edits: [Vec<Change>; PARTITIONS] = std::array::from_fn(|_| Vec::new());
    let mut dirty = 0_u64;
    for change in delta {
        let index = partition(change.key);
        dirty |= 1_u64 << index;
        edits[index].push(*change);
    }
    let mut writes = Vec::new();
    let mut references = Vec::new();
    // Only dirty partitions are read; each decoded state is dropped after encoding.
    visit(
        source,
        snapshot,
        &manifest,
        dirty,
        dirty,
        usize::MAX,
        |chunk| {
            if dirty & (1_u64 << chunk.index) == 0 {
                return Ok(());
            }
            let mut state = decode(&chunk, &manifest)?;
            let next = state
                .sequence()
                .checked_add(1)
                .filter(|n| *n <= i64::MAX as u64)
                .ok_or("checkpoint chunk revision exhausted")?;
            state
                .apply(
                    Batch {
                        binding: state.binding(),
                        previous: state.sequence(),
                        next,
                        changes: &edits[chunk.index],
                    },
                    keep,
                )
                .map_err(|_| "checkpoint replay rejected the captured event prefix")?;
            let (reference, write) = encode(chunk.index, &state)?;
            references.push((chunk.index, reference));
            writes.push(write);
            Ok(())
        },
    )?;
    for (index, reference) in references {
        manifest.chunks[index] = reference;
    }
    manifest.applied = h.emitted as u64;
    manifest.generation = manifest
        .generation
        .checked_add(1)
        .filter(|n| *n <= i64::MAX as u64)
        .ok_or("checkpoint generation exhausted")?;
    if i64::from(manifest.rows().map_err(|_| "invalid_checkpoint")?) != h.rows {
        return Err("checkpoint row count disagrees with capture head");
    }
    persist(source, &manifest, writes)
}
