//! Versioned keyed state. Bounds and CRC are checked before row allocation.
use super::{Binding, Limits, ReplayState, Row};
use crate::{i32_at, u16_at, u32_at, SegmentError, MAX_ROWS, MAX_SEGMENT_BYTES};
use std::mem::size_of;

const HEADER: usize = 112;
const MAGIC: &[u8; 8] = b"SYNTRACP";
fn poll(keep: &mut impl FnMut() -> bool) -> Result<(), SegmentError> {
    if keep() {
        Ok(())
    } else {
        Err(SegmentError::Cancelled)
    }
}
fn u64_at(bytes: &[u8], offset: usize) -> Result<u64, SegmentError> {
    let value = bytes
        .get(offset..offset + 8)
        .ok_or(SegmentError::Truncated)?;
    Ok(u64::from_le_bytes(
        value.try_into().map_err(|_| SegmentError::Truncated)?,
    ))
}
fn checksum(bytes: &[u8], keep: &mut impl FnMut() -> bool) -> Result<u32, SegmentError> {
    let mut crc = crc32fast::Hasher::new();
    for slice in [&bytes[..104], &bytes[108..]] {
        for chunk in slice.chunks(65536) {
            poll(keep)?;
            crc.update(chunk);
        }
    }
    Ok(crc.finalize())
}
fn length(rows: usize) -> Result<(usize, usize), SegmentError> {
    if rows > MAX_ROWS {
        return Err(SegmentError::LimitExceeded);
    }
    let bitmap = rows.div_ceil(8);
    let total = rows
        .checked_mul(8)
        .and_then(|n| n.checked_add(bitmap + HEADER))
        .ok_or(SegmentError::LimitExceeded)?;
    if total > MAX_SEGMENT_BYTES {
        return Err(SegmentError::LimitExceeded);
    }
    Ok((bitmap, total))
}
impl ReplayState {
    /// Exact encoded checkpoint length for `rows`, independent of keys and values.
    pub fn encoded_checkpoint_len(rows: usize) -> Result<usize, SegmentError> {
        length(rows).map(|(_, total)| total)
    }
    pub fn encode_checkpoint(
        &self,
        mut keep: impl FnMut() -> bool,
    ) -> Result<Vec<u8>, SegmentError> {
        poll(&mut keep)?;
        let (bitmap, total) = length(self.rows.len())?;
        let mut bytes = Vec::new();
        bytes
            .try_reserve_exact(total)
            .map_err(|_| SegmentError::AllocationFailed)?;
        bytes.resize(total, 0);
        bytes[..8].copy_from_slice(MAGIC);
        bytes[8..10].copy_from_slice(&1_u16.to_le_bytes());
        bytes[10..12].copy_from_slice(&u16::from(self.last_digest.is_some()).to_le_bytes());
        bytes[12..16].copy_from_slice(&(self.rows.len() as u32).to_le_bytes());
        bytes[16..48].copy_from_slice(&self.binding.stream);
        bytes[48..56].copy_from_slice(&self.binding.epoch.to_le_bytes());
        bytes[56..64].copy_from_slice(&self.sequence.to_le_bytes());
        if let Some(digest) = self.last_digest {
            bytes[64..96].copy_from_slice(&digest);
        }
        bytes[96..104].copy_from_slice(&((total - HEADER) as u64).to_le_bytes());
        for (index, row) in self.rows.iter().enumerate() {
            if index % 1024 == 0 {
                poll(&mut keep)?;
            }
            let offset = HEADER + bitmap + index * 8;
            bytes[offset..offset + 4].copy_from_slice(&row.key.to_le_bytes());
            if let Some(value) = row.value {
                bytes[offset + 4..offset + 8].copy_from_slice(&value.to_le_bytes());
            } else {
                bytes[HEADER + index / 8] |= 1 << (index % 8);
            }
        }
        let crc = checksum(&bytes, &mut keep)?;
        bytes[104..108].copy_from_slice(&crc.to_le_bytes());
        Ok(bytes)
    }
    pub fn decode_checkpoint(
        bytes: &[u8],
        limits: Limits,
        mut keep: impl FnMut() -> bool,
    ) -> Result<Self, SegmentError> {
        poll(&mut keep)?;
        if bytes.len() < HEADER {
            return Err(SegmentError::Truncated);
        }
        if bytes.len() > MAX_SEGMENT_BYTES {
            return Err(SegmentError::LimitExceeded);
        }
        if &bytes[..8] != MAGIC {
            return Err(SegmentError::InvalidHeader);
        }
        let version = u16_at(bytes, 8)?;
        if version != 1 {
            return Err(SegmentError::UnsupportedVersion(version));
        }
        let flags = u16_at(bytes, 10)?;
        if flags > 1 || bytes[108..112] != [0; 4] {
            return Err(SegmentError::NonCanonical);
        }
        let count = u32_at(bytes, 12)? as usize;
        let (bitmap, total) = length(count)?;
        if total != bytes.len() || u64_at(bytes, 96)? != (total - HEADER) as u64 {
            return Err(SegmentError::InvalidMetadata);
        }
        if checksum(bytes, &mut keep)? != u32_at(bytes, 104)? {
            return Err(SegmentError::ChecksumMismatch);
        }
        if limits.rows > MAX_ROWS || !(1..=4096).contains(&limits.changes) {
            return Err(SegmentError::InvalidMetadata);
        }
        if count > limits.rows
            || count
                .checked_mul(size_of::<Row>())
                .is_none_or(|n| n > limits.buffer_bytes)
        {
            return Err(SegmentError::LimitExceeded);
        }
        let epoch = u64_at(bytes, 48)?;
        if epoch == 0 {
            return Err(SegmentError::InvalidMetadata);
        }
        if flags == 0 && bytes[64..96].iter().any(|b| *b != 0) {
            return Err(SegmentError::NonCanonical);
        }
        if !count.is_multiple_of(8) && bytes[HEADER + bitmap - 1] >> (count % 8) != 0 {
            return Err(SegmentError::NonCanonical);
        }
        let mut rows = Vec::new();
        rows.try_reserve_exact(count)
            .map_err(|_| SegmentError::AllocationFailed)?;
        for index in 0..count {
            if index % 1024 == 0 {
                poll(&mut keep)?;
            }
            let offset = HEADER + bitmap + index * 8;
            let key = i32_at(bytes, offset)?;
            let value = i32_at(bytes, offset + 4)?;
            if rows.last().is_some_and(|row: &Row| row.key >= key) {
                return Err(SegmentError::NonCanonical);
            }
            let null = bytes[HEADER + index / 8] & (1 << (index % 8)) != 0;
            if null && value != 0 {
                return Err(SegmentError::NonCanonical);
            }
            rows.push(Row {
                key,
                value: (!null).then_some(value),
            });
        }
        let mut stream = [0; 32];
        stream.copy_from_slice(&bytes[16..48]);
        let last_digest = if flags == 1 {
            let mut value = [0; 32];
            value.copy_from_slice(&bytes[64..96]);
            Some(value)
        } else {
            None
        };
        poll(&mut keep)?;
        Ok(Self {
            binding: Binding { stream, epoch },
            sequence: u64_at(bytes, 56)?,
            rows,
            last_digest,
            limits,
        })
    }
}
