//! Private, bounded transactional changes. No SQL reader routes through this log.
use crate::native_catalog::{function_oid, guards_current, oid_key, CatalogScan};
use pgrx::prelude::*;
use pgrx::trigger_support::{PgTriggerLevel, PgTriggerWhen};
use pgrx::{AllocatedByPostgres, PgRelation};
use std::{ffi::CStr, num::NonZeroUsize};

fn stale() -> ! {
    pgrx::ereport!(
        ERROR,
        pgrx::PgSqlErrorCode::ERRCODE_OBJECT_NOT_IN_PREREQUISITE_STATE,
        "capture configuration is missing or changed; reseed before writing"
    );
}

fn trigger_valid(source: &PgRelation, oid: pg_sys::Oid, procedure: pg_sys::Oid, kind: i16) -> bool {
    // SAFETY: source is locked for the statement; all descriptor fields are
    // inspected synchronously and no catalog pointer escapes.
    unsafe {
        if source.trigdesc.is_null() {
            return false;
        }
        let desc = &*source.trigdesc;
        (0..desc.numtriggers).any(|index| {
            let t = &*desc.triggers.add(index as usize);
            t.tgoid == oid
                && t.tgfoid == procedure
                && t.tgtype == kind
                && t.tgenabled as u8 == b'A'
                && !t.tgisinternal
                && !t.tgisclone
                && t.tgnargs == 0
                && t.tgnattr == 0
                && t.tgqual.is_null()
                && t.tgconstraint == pg_sys::InvalidOid
                && !t.tgdeferrable
                && !t.tginitdeferred
                && t.tgoldtable.is_null()
                && t.tgnewtable.is_null()
        })
    }
}

fn install(
    source: &PgRelation,
    name: &CStr,
    function: &'static CStr,
    events: i16,
    row: bool,
    before: bool,
) -> pg_sys::Oid {
    let procedure =
        function_oid(function).unwrap_or_else(|| pgrx::error!("capture function is missing"));
    let kind = events
        | i16::from(row)
        | if before {
            pg_sys::TRIGGER_TYPE_BEFORE as i16
        } else {
            0
        };
    // SAFETY: caller holds source AccessExclusiveLock. Identifiers are static,
    // source is nonpartitioned, and PostgreSQL owns all statement allocations.
    unsafe {
        let existing = pg_sys::get_trigger_oid(source.oid(), name.as_ptr(), true);
        if existing != pg_sys::InvalidOid {
            if !trigger_valid(source, existing, procedure, kind) {
                pgrx::error!("existing capture trigger is incompatible; repair it before seeding");
            }
            return existing;
        }
        let mut statement =
            PgBox::<pg_sys::CreateTrigStmt>::alloc_node(pg_sys::NodeTag::T_CreateTrigStmt);
        statement.trigname = pg_sys::pstrdup(name.as_ptr());
        statement.events = events;
        statement.row = row;
        statement.timing = if before {
            pg_sys::TRIGGER_TYPE_BEFORE as i16
        } else {
            0
        };
        pg_sys::CreateTriggerFiringOn(
            statement.as_ptr(),
            c"SyntraDB bounded capture".as_ptr(),
            source.oid(),
            pg_sys::InvalidOid,
            pg_sys::InvalidOid,
            pg_sys::InvalidOid,
            procedure,
            pg_sys::InvalidOid,
            std::ptr::null_mut(),
            false,
            false,
            pg_sys::TRIGGER_FIRES_ALWAYS as std::ffi::c_char,
        )
        .objectId
    }
}

pub(super) struct Snapshot;
impl Snapshot {
    pub(super) fn latest() -> Self {
        // SAFETY: backend main thread; the caller holds its source relation lock.
        // Push copies/pins the snapshot until this guard is dropped.
        unsafe {
            pg_sys::PushActiveSnapshot(pg_sys::GetLatestSnapshot());
        }
        Self
    }
    fn text(&self) -> String {
        // SAFETY: this guard holds the active native snapshot. These builtins
        // serialize it without SPI and the text is copied before any pop.
        unsafe {
            let datum = pgrx::direct_function_call_as_datum(pg_sys::pg_current_snapshot, &[])
                .unwrap_or_else(|| pgrx::error!("cannot obtain capture snapshot"));
            pgrx::direct_function_call::<&CStr>(pg_sys::pg_snapshot_out, &[Some(datum)])
                .unwrap_or_else(|| pgrx::error!("cannot describe capture snapshot"))
                .to_string_lossy()
                .into_owned()
        }
    }
}
impl Drop for Snapshot {
    fn drop(&mut self) {
        // SAFETY: exactly one matching push; no callback retains its pointer.
        unsafe {
            pg_sys::PopActiveSnapshot();
        }
    }
}

#[pg_extern(volatile, parallel_unsafe)]
fn syntra_seed_capture(
    source: PgRelation,
    key_column: &str,
    value_column: &str,
    max_events: i32,
) -> i64 {
    // SAFETY: backend-local privilege and isolation settings.
    unsafe {
        if !pg_sys::superuser() {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_INSUFFICIENT_PRIVILEGE,
                "capture seeding currently requires a superuser"
            );
        }
        if pg_sys::XactReadOnly || pg_sys::XactIsoLevel >= pg_sys::XACT_REPEATABLE_READ as i32 {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
                "capture seeding requires a writable read committed transaction"
            );
        }
        // Retain the exclusive lock through commit. Reject an active source
        // executor: installing a trigger mid-statement could miss remaining rows.
        pg_sys::LockRelationOid(source.oid(), pg_sys::AccessExclusiveLock as i32);
        pg_sys::CheckTableNotInUse(source.as_ptr(), c"seed capture".as_ptr());
    }
    if !(1..=4096).contains(&max_events) {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_INVALID_PARAMETER_VALUE,
            "capture event limit must be between 1 and 4096"
        );
    }
    let key = crate::source::validate_source(&source, key_column);
    let value = crate::source::validate_source(&source, value_column);
    // SAFETY: source exclusive lock protects all relation flags.
    if unsafe {
        (*source.rd_rel).relpersistence as u8 != pg_sys::RELPERSISTENCE_PERMANENT
            || (*source.rd_rel).relhasrules
            || pg_sys::has_superclass(source.oid())
    } || matches!(source.namespace(), "syntra" | "pg_catalog" | "pg_toast")
    {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
            "capture requires a permanent heap without inheritance or rewrite rules"
        );
    }
    let primary = Spi::get_one_with_args::<bool>(
        r#"SELECT count(*)=1 FROM pg_catalog.pg_index AS i
        JOIN pg_catalog.pg_constraint AS c ON c.conindid=i.indexrelid AND c.contype='p'
        WHERE i.indrelid=$1 AND i.indisprimary AND i.indisvalid AND i.indisready
        AND i.indisunique AND i.indimmediate AND i.indnkeyatts=1 AND i.indkey[0]=$2
        AND i.indpred IS NULL AND i.indexprs IS NULL AND NOT c.condeferrable"#,
        &[source.oid().into(), key.into()],
    )
    .unwrap_or_else(|e| pgrx::error!("{}", e));
    if primary != Some(true) {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
            "capture requires a single nondeferrable int4 primary key"
        );
    }
    // Nested writes from earlier AFTER ROW or RI triggers can reverse callback
    // order relative to actual tuple changes. Reject that scope until capture
    // has a tested ordering protocol for arbitrary trigger interactions.
    let no_other_triggers=Spi::get_one_with_args::<bool>("SELECT count(*)=0 FROM pg_catalog.pg_trigger WHERE tgrelid=$1 AND tgname NOT IN ('_syntra_source_changed','_syntra_capture_row','_syntra_capture_no_truncate')",&[source.oid().into()])
        .unwrap_or_else(|e|pgrx::error!("{}",e));
    if no_other_triggers != Some(true) {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
            "capture does not support other source triggers or foreign-key triggers"
        );
    }
    // Nonblocking, transaction-level admission bounds the global live feed count.
    // This experimental setup lock can conflict with writers on other feeds.
    unsafe {
        let namespace = pg_sys::get_namespace_oid(c"syntra".as_ptr(), false);
        let catalog = pg_sys::get_relname_relid(c"capture_heads".as_ptr(), namespace);
        if !pg_sys::ConditionalLockRelationOid(catalog, pg_sys::ShareRowExclusiveLock as i32) {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_LOCK_NOT_AVAILABLE,
                "capture setup is busy; retry after active capture transactions end"
            );
        }
    }
    let _tracking_epoch = Spi::get_one_with_args::<i64>(
        "SELECT public.syntra_track_source($1::regclass,$2)",
        &[source.oid().into(), value_column.into()],
    )
    .unwrap_or_else(|e| pgrx::error!("{}", e))
    .unwrap_or_else(|| pgrx::error!("capture source registration failed"));
    // Refresh this backend's relcache after native trigger installation.
    // SAFETY: this backend already holds the source exclusive lock.
    let fresh = unsafe { PgRelation::with_lock(source.oid(), pg_sys::AccessShareLock as i32) };
    let row_trigger = install(
        &fresh,
        c"_syntra_capture_row",
        c"public.syntra_capture_row()",
        28,
        true,
        false,
    );
    // SAFETY: source exclusive lock is still held; reopen reloads trigger metadata.
    let fresh = unsafe { PgRelation::with_lock(source.oid(), pg_sys::AccessShareLock as i32) };
    let truncate_trigger = install(
        &fresh,
        c"_syntra_capture_no_truncate",
        c"public.syntra_capture_no_truncate()",
        32,
        false,
        true,
    );
    let snapshot = Snapshot::latest();
    let snapshot_text = snapshot.text();
    // SAFETY: the seed guard pins the exact snapshot used for the source scan.
    let base_command = unsafe { i64::from((*pg_sys::GetActiveSnapshot()).curcid) };
    let rows = crate::source::keyed_seed(&source, key, value, crate::source::source_snapshot());
    let row_count = rows.len() as i64;
    let identity = crate::live::identity(&source, value);
    Spi::run_with_args("DELETE FROM syntra.capture_chunks WHERE source_relation=$1; DELETE FROM syntra.capture_checkpoints WHERE source_relation=$1; DELETE FROM syntra.capture_events WHERE source_relation=$1; DELETE FROM syntra.capture_base_rows WHERE source_relation=$1; DELETE FROM syntra.capture_heads WHERE source_relation=$1",&[source.oid().into()])
        .unwrap_or_else(|e|pgrx::error!("{}",e));
    let epoch=Spi::get_one_with_args::<i64>(r#"WITH seeded AS (INSERT INTO syntra.capture_heads
        (source_relation,tracking_epoch,key_attribute,value_attribute,row_trigger,truncate_trigger,max_events,source_identity,base_snapshot,base_rows,base_command,live_rows)
        SELECT $1,s.epoch,$2,$3,$4,$5,$6,$7,$8,$9,$10,$9 FROM syntra.tracked_sources AS s
        WHERE s.source_relation=$1 AND (SELECT count(*) FROM syntra.capture_heads)<16 RETURNING epoch)
        SELECT max(epoch) FROM seeded"#,
        &[source.oid().into(),key.into(),value.into(),row_trigger.into(),truncate_trigger.into(),max_events.into(),
            identity.as_str().into(),snapshot_text.as_str().into(),row_count.into(),base_command.into()])
        .unwrap_or_else(|e|pgrx::error!("{}",e)).unwrap_or_else(||{
            pgrx::ereport!(ERROR,pgrx::PgSqlErrorCode::ERRCODE_PROGRAM_LIMIT_EXCEEDED,"capture limit of 16 sources reached");
        });
    let mut keys = Vec::new();
    let mut values = Vec::new();
    keys.try_reserve_exact(rows.len()).unwrap_or_else(|_| {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_OUT_OF_MEMORY,
            "cannot allocate capture keys"
        );
    });
    values.try_reserve_exact(rows.len()).unwrap_or_else(|_| {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_OUT_OF_MEMORY,
            "cannot allocate capture values"
        );
    });
    for row in &rows {
        keys.push(row.key);
        values.push(row.value);
    }
    Spi::run_with_args("INSERT INTO syntra.capture_base_rows(source_relation,epoch,key,value) SELECT $1,$2,r.key,r.value FROM unnest($3::int4[],$4::int4[]) AS r(key,value)",
        &[source.oid().into(),epoch.into(),keys.into(),values.into()]).unwrap_or_else(|e|pgrx::error!("{}",e));
    drop(snapshot);
    epoch
}

pub(super) struct Configuration {
    pub(super) key: i16,
    pub(super) value: i16,
    pub(super) epoch: i64,
    pub(super) tracking_epoch: i64,
    pub(super) row: pg_sys::Oid,
    pub(super) truncate: pg_sys::Oid,
    pub(super) identity: String,
}

#[pg_extern(volatile, parallel_unsafe)]
fn syntra_stop_capture(source: PgRelation) -> bool {
    // SAFETY: backend-local settings and relation lock APIs. Native dependency
    // deletion below is authorized only for explicit admin capture retirement.
    unsafe {
        if !pg_sys::superuser() {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_INSUFFICIENT_PRIVILEGE,
                "capture retirement currently requires a superuser"
            );
        }
        if pg_sys::XactReadOnly || pg_sys::XactIsoLevel >= pg_sys::XACT_REPEATABLE_READ as i32 {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
                "capture retirement requires a writable read committed transaction"
            );
        }
        pg_sys::LockRelationOid(source.oid(), pg_sys::AccessExclusiveLock as i32);
        pg_sys::CheckTableNotInUse(source.as_ptr(), c"stop capture".as_ptr());
    }
    let row_function = function_oid(c"public.syntra_capture_row()").unwrap_or_else(|| stale());
    let truncate_function =
        function_oid(c"public.syntra_capture_no_truncate()").unwrap_or_else(|| stale());
    let mut triggers = Vec::new();
    // SAFETY: inspect and copy all OIDs before deletion invalidates the relcache.
    // Only this source's triggers using our two capture functions are selected.
    unsafe {
        if !source.trigdesc.is_null() {
            let desc = &*source.trigdesc;
            for index in 0..desc.numtriggers {
                let trigger = &*desc.triggers.add(index as usize);
                if trigger.tgfoid == row_function || trigger.tgfoid == truncate_function {
                    triggers.push(trigger.tgoid);
                }
            }
        }
        for oid in &triggers {
            let address = pg_sys::ObjectAddress {
                classId: pg_sys::TriggerRelationId,
                objectId: *oid,
                objectSubId: 0,
            };
            pg_sys::performDeletion(&address, pg_sys::DropBehavior::DROP_RESTRICT, 0);
        }
    }
    Spi::run_with_args("DELETE FROM syntra.capture_chunks WHERE source_relation=$1; DELETE FROM syntra.capture_checkpoints WHERE source_relation=$1; DELETE FROM syntra.capture_events WHERE source_relation=$1; DELETE FROM syntra.capture_base_rows WHERE source_relation=$1",&[source.oid().into()])
        .unwrap_or_else(|e|pgrx::error!("{}",e));
    let removed=Spi::get_one_with_args::<i64>("WITH removed AS (DELETE FROM syntra.capture_heads WHERE source_relation=$1 RETURNING epoch) SELECT count(*) FROM removed",&[source.oid().into()])
        .unwrap_or_else(|e|pgrx::error!("{}",e));
    let changed = removed == Some(1) || !triggers.is_empty();
    if changed {
        Spi::run_with_args(
            "UPDATE syntra.tracked_sources SET epoch=DEFAULT WHERE source_relation=$1",
            &[source.oid().into()],
        )
        .unwrap_or_else(|e| pgrx::error!("{}", e));
    }
    changed
}
/// Advisory room left in a captured source's event feed, for producers that want
/// to slow down before the hard "capture log is full" error. Counts committed
/// events only: concurrent open transactions can still use the free events, so it
/// is a signal, not a reservation. Any role that can read or write the source may
/// ask; the private head row is read natively because roles have no catalog access.
#[pg_extern(volatile, parallel_unsafe)]
fn syntra_capture_headroom(
    source: PgRelation,
) -> TableIterator<
    'static,
    (
        name!(retained_events, i64),
        name!(max_events, i32),
        name!(free_events, i64),
        name!(live_rows, i64),
    ),
> {
    // SAFETY: backend-local ACL lookups on the relation opened by pgrx's REGCLASS adapter.
    unsafe {
        let role = pg_sys::GetUserId();
        let any = u64::from(
            pg_sys::ACL_SELECT | pg_sys::ACL_INSERT | pg_sys::ACL_UPDATE | pg_sys::ACL_DELETE,
        );
        if pg_sys::object_aclcheck(
            pg_sys::NamespaceRelationId,
            source.namespace_oid(),
            role,
            pg_sys::ACL_USAGE.into(),
        ) != pg_sys::AclResult::ACLCHECK_OK
            || pg_sys::pg_class_aclmask(source.oid(), role, any, pg_sys::AclMaskHow::ACLMASK_ANY)
                == 0
        {
            pgrx::ereport!(
                ERROR,
                pgrx::PgSqlErrorCode::ERRCODE_INSUFFICIENT_PRIVILEGE,
                "capture headroom requires schema USAGE and a table privilege"
            );
        }
    }
    let _snapshot_guard = Snapshot::latest();
    // SAFETY: the guard above pins this MVCC snapshot through the scan.
    let snapshot = unsafe { pg_sys::GetActiveSnapshot() };
    let mut scan = CatalogScan::open(
        c"syntra",
        c"capture_heads",
        c"capture_heads_pkey",
        snapshot,
        &[oid_key(1, "source_relation", source.oid())],
    )
    .unwrap_or_else(|| stale());
    let h = scan.next_back().unwrap_or_else(|| stale());
    let read = |attribute, name| h.get::<i64>(attribute, name).unwrap_or_else(|| stale());
    let max_events = h.get::<i32>(8, "max_events").unwrap_or_else(|| stale());
    let (emitted, pruned, live_rows) = (
        read(9, "emitted"),
        read(15, "pruned"),
        read(16, "live_rows"),
    );
    let retained = emitted - pruned;
    if pruned < 0 || retained < 0 || retained > i64::from(max_events) {
        stale();
    }
    TableIterator::new(std::iter::once((
        retained,
        max_events,
        i64::from(max_events) - retained,
        live_rows,
    )))
}

pub(super) fn current_configuration(
    source: &PgRelation,
) -> std::result::Result<Configuration, &'static str> {
    // Configuration must be current even when the writing transaction has an old
    // repeatable-read snapshot. Never use its stale tracked epoch as DDL proof.
    let _snapshot_guard = Snapshot::latest();
    // SAFETY: the guard above pins this MVCC snapshot through both catalog scans.
    let snapshot = unsafe { pg_sys::GetActiveSnapshot() };
    let mut scan = CatalogScan::open(
        c"syntra",
        c"capture_heads",
        c"capture_heads_pkey",
        snapshot,
        &[oid_key(1, "source_relation", source.oid())],
    )
    .ok_or("capture_unavailable")?;
    let h = scan.next_back().ok_or("capture_unavailable")?;
    let config = Configuration {
        key: h.get(4, "key_attribute").ok_or("capture_unavailable")?,
        value: h.get(5, "value_attribute").ok_or("capture_unavailable")?,
        epoch: h.get(2, "epoch").ok_or("capture_unavailable")?,
        tracking_epoch: h.get(3, "tracking_epoch").ok_or("capture_unavailable")?,
        row: h.get(6, "row_trigger").ok_or("capture_unavailable")?,
        truncate: h.get(7, "truncate_trigger").ok_or("capture_unavailable")?,
        identity: h.get(10, "source_identity").ok_or("capture_unavailable")?,
    };
    drop(scan);
    let mut tracked = CatalogScan::open(
        c"syntra",
        c"tracked_sources",
        c"tracked_sources_pkey",
        snapshot,
        &[oid_key(1, "source_relation", source.oid())],
    )
    .ok_or("capture_unavailable")?;
    let h = tracked.next().ok_or("capture_unavailable")?;
    let statement_guard = h
        .get::<pg_sys::Oid>(2, "trigger_oid")
        .ok_or("capture_unavailable")?;
    if h.get::<i64>(3, "epoch") != Some(config.tracking_epoch)
        || !guards_current(source, statement_guard)
        || unsafe { source.trigdesc.is_null() || (*source.trigdesc).numtriggers != 3 }
        || config.identity != crate::live::identity(source, config.value)
        || !trigger_valid(
            source,
            config.row,
            function_oid(c"public.syntra_capture_row()").ok_or("capture_unavailable")?,
            29,
        )
        || !trigger_valid(
            source,
            config.truncate,
            function_oid(c"public.syntra_capture_no_truncate()").ok_or("capture_unavailable")?,
            34,
        )
    {
        return Err("capture_unavailable");
    }
    let descriptor = source.tuple_desc();
    if ![config.key, config.value].iter().all(|number| {
        descriptor
            .iter()
            .any(|a| a.attnum == *number && !a.attisdropped && a.atttypid == pg_sys::INT4OID)
    }) || unsafe {
        // A callback can arrive after source DDL changed its supported scope.
        // Check current relation flags before extracting tuple attributes.
        (*source.rd_rel).relrowsecurity
            || (*source.rd_rel).relhasrules
            || (*source.rd_rel).relhassubclass
            || (*source.rd_rel).relispartition
            || (*source.rd_rel).relpersistence as u8 != pg_sys::RELPERSISTENCE_PERMANENT
            || pg_sys::has_superclass(source.oid())
    } {
        return Err("capture_unavailable");
    }
    Ok(config)
}

fn configuration(source: &PgRelation, trigger: pg_sys::Oid) -> Configuration {
    let config = current_configuration(source).unwrap_or_else(|_| stale());
    if trigger != config.row {
        stale();
    }
    config
}

fn pair(
    tuple: Option<PgHeapTuple<'_, AllocatedByPostgres>>,
    config: &Configuration,
) -> Option<(i32, Option<i32>)> {
    tuple.map(|tuple| {
        let key = tuple
            .get_by_index::<i32>(NonZeroUsize::new(config.key as usize).unwrap_or_else(|| stale()))
            .unwrap_or_else(|e| pgrx::error!("{}", e))
            .unwrap_or_else(|| stale());
        let value = tuple
            .get_by_index::<i32>(
                NonZeroUsize::new(config.value as usize).unwrap_or_else(|| stale()),
            )
            .unwrap_or_else(|e| pgrx::error!("{}", e));
        (key, value)
    })
}

#[pg_trigger]
fn syntra_capture_row<'a>(
    trigger: &'a PgTrigger<'a>,
) -> Result<Option<PgHeapTuple<'a, AllocatedByPostgres>>, pgrx::spi::Error> {
    if !matches!(trigger.level(), PgTriggerLevel::Row)
        || !matches!(trigger.when(), Ok(PgTriggerWhen::After))
    {
        stale();
    }
    let oid = trigger.relid().unwrap_or_else(|_| stale());
    let source = unsafe { PgRelation::with_lock(oid, pg_sys::AccessShareLock as i32) };
    let config = configuration(&source, trigger.trigger().tgoid);
    let old = pair(trigger.old(), &config);
    let new = pair(trigger.new(), &config);
    let mut changes = Vec::with_capacity(2);
    if let (Some((key, before)), Some((next, after))) = (old, new) {
        if key == next {
            changes.push((key, Some(before), Some(after)));
        } else {
            changes.push((key, Some(before), None));
            changes.push((next, None, Some(after)));
        }
    } else {
        if let Some((key, value)) = old {
            changes.push((key, Some(value), None));
        }
        if let Some((key, value)) = new {
            changes.push((key, None, Some(value)));
        }
    }
    if changes.is_empty() {
        stale();
    }
    let row_delta = i64::from(new.is_some()) - i64::from(old.is_some());
    let count = changes.len() as i32;
    let keys: Vec<i32> = changes.iter().map(|c| c.0).collect();
    let before: Vec<bool> = changes.iter().map(|c| c.1.is_some()).collect();
    let old: Vec<Option<i32>> = changes.iter().map(|c| c.1.flatten()).collect();
    let after: Vec<bool> = changes.iter().map(|c| c.2.is_some()).collect();
    let new: Vec<Option<i32>> = changes.iter().map(|c| c.2.flatten()).collect();
    let command = unsafe { i64::from(pg_sys::GetCurrentCommandId(false)) };
    let inserted = Spi::get_one_with_args::<i64>(
        r#"WITH reserved AS (
        UPDATE syntra.capture_heads AS h SET emitted=h.emitted+$4,live_rows=h.live_rows+$11
        FROM syntra.tracked_sources AS s WHERE h.source_relation=$1 AND h.epoch=$2
        AND h.row_trigger=$3 AND s.source_relation=h.source_relation AND s.epoch=h.tracking_epoch
        AND h.emitted-h.pruned<=h.max_events-$4 AND h.emitted<=9223372036854775807-$4
        AND h.live_rows+$11 BETWEEN 0 AND 1000000 RETURNING h.epoch,h.emitted-$4 AS start
    ), inserted AS (
        INSERT INTO syntra.capture_events(source_relation,epoch,ordinal,origin_xid,command_id,key,before_present,before_value,after_present,after_value)
        SELECT $1,r.epoch,r.start+e.position,pg_catalog.pg_current_xact_id(),$10,e.key,e.bp,e.bv,e.ap,e.av
        FROM reserved AS r, unnest($5::int4[],$6::boolean[],$7::int4[],$8::boolean[],$9::int4[])
        WITH ORDINALITY AS e(key,bp,bv,ap,av,position) RETURNING ordinal
    ) SELECT count(*) FROM inserted"#,
        &[
            oid.into(),
            config.epoch.into(),
            trigger.trigger().tgoid.into(),
            count.into(),
            keys.into(),
            before.into(),
            old.into(),
            after.into(),
            new.into(),
            command.into(),
            row_delta.into(),
        ],
    )?;
    if inserted != Some(i64::from(count)) {
        pgrx::ereport!(
            ERROR,
            pgrx::PgSqlErrorCode::ERRCODE_PROGRAM_LIMIT_EXCEEDED,
            "capture log is full or registration changed; apply and prune or reseed before writing"
        );
    }
    Ok(None)
}

#[pg_trigger]
fn syntra_capture_no_truncate<'a>(
    _trigger: &'a PgTrigger<'a>,
) -> Result<Option<PgHeapTuple<'a, AllocatedByPostgres>>, pgrx::spi::Error> {
    pgrx::ereport!(
        ERROR,
        pgrx::PgSqlErrorCode::ERRCODE_FEATURE_NOT_SUPPORTED,
        "TRUNCATE is not supported while capture is installed"
    );
}
